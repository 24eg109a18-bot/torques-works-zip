# TorqueWorks: Car Service & Garage Management System

Full-stack college major project: **React (Vite) + Spring Boot 3 + MySQL**, secured with **Spring Security + JWT**.
Customers book services, mechanics run the job card, and the admin manages the whole garage.
The home page has an animated **3D car** (Three.js) hovering over a service bay.

```
car-service-garage-management/
├── backend/     Spring Boot REST API (Java 17+, Maven)
├── frontend/    React app (Vite, Bootstrap, Axios, React Router, Recharts, Three.js)
├── database/    schema.sql, sample_data.sql
├── docs/        Project report, API docs, viva guide, 3D portfolio prompt
└── postman/     Ready-to-import Postman collection
```

## 1. Requirements
| Tool | Version |
|---|---|
| JDK | 17 or 21 (JDK 17/21 recommended) |
| Maven | 3.9+ (or let IntelliJ / VS Code Java extensions handle Maven) |
| Node.js | 18+ (20 recommended) |
| MySQL | 8.x (MySQL Workbench optional) |

## 2. Connect MySQL
1. Start MySQL and make sure you know your root password.
2. Open `backend/src/main/resources/application.properties` and edit:
   ```
   spring.datasource.username=root
   spring.datasource.password=YOUR_PASSWORD
   ```
3. Nothing else is needed: `createDatabaseIfNotExist=true` creates `garage_db`, and Hibernate creates all tables
   (`ddl-auto=update`). On the first start the app also inserts demo data (`DataSeeder.java`).
   `database/schema.sql` is only a reference/manual alternative.

## 3. Run the backend (port 8080)
```bash
cd backend
mvn spring-boot:run
```
In VS Code: install **Extension Pack for Java** + **Spring Boot Extension Pack**, open `backend`, and run
`GarageManagementApplication`. Wait for `Started GarageManagementApplication`.

## 4. Run the frontend (port 5173)
```bash
cd frontend
npm install
npm run dev
```
Open **http://localhost:5173**. The API address is in `frontend/.env` (`VITE_API_URL=http://localhost:8080/api`).

## 5. Test credentials (created automatically)
| Role | Email | Password |
|---|---|---|
| Admin | admin@garage.com | Admin@123 |
| Mechanic | ravi@garage.com | Mechanic@123 |
| Mechanic | suresh@garage.com / anil@garage.com | Mechanic@123 |
| Customer | rahul@example.com | Customer@123 |
| Customer | priya@example.com / amit@example.com | Customer@123 |

## 6. Try the full workflow (5-minute demo)
1. Log in as **rahul@example.com**, open *Book Service*, pick a car, service, a future date and time.
2. Log in as **admin@garage.com** → *Appointments* → **Approve** → **Assign** a mechanic (try assigning the same mechanic to the same slot twice to see double-booking prevention).
3. Log in as the **mechanic** → *Assigned Services* → open the job → add inspection notes + labour → add spare parts (watch inventory drop) → **Start work** → **Mark completed** (invoice is generated automatically).
4. Back as **customer**: *Service Tracking*, *Invoices* (download/print as PDF), *Payment* (simulated), *Feedback*.
5. Back as **admin**: *Dashboard* charts, *Inventory* low-stock warnings, *Reports* (CSV export).

## 7. Postman
Import `postman/Garage-Management.postman_collection.json`. Run **Auth → Login (Admin)** first; the token is saved
automatically in the `{{token}}` variable and used by all other requests. More examples are in `docs/API_DOCUMENTATION.md`.

## 8. Troubleshooting
| Problem | Fix |
|---|---|
| `Access denied for user 'root'` | Wrong MySQL password in `application.properties` |
| `Communications link failure` | MySQL is not running / wrong port |
| Frontend shows "Cannot reach the server" | Backend not started, or port 8080 busy |
| CORS error in browser | Frontend must run on `localhost:5173` (or add your origin to `app.cors.allowed-origins`) |
| Lombok errors in the IDE | Install the Lombok plugin / enable annotation processing |
| Want fresh demo data | Drop the database (`DROP DATABASE garage_db;`) and restart the backend |

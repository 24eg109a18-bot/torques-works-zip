# Car Service & Garage Management System (TorqueWorks)
*College major project report*

## 1. Project Abstract
The Car Service & Garage Management System is a full-stack web application that digitises the daily work of a car service garage. Customers register, add their vehicles, book service appointments and track progress online. Mechanics receive assigned jobs, record inspection notes, labour and spare parts, and update the job status. The administrator controls customers, mechanics, services, inventory, invoices, payments and reports from a dashboard. The system is built with React on the front end, Spring Boot REST APIs on the back end and MySQL for storage, and is protected by Spring Security with JWT-based role authorisation. Business rules such as double-booking prevention, valid status transitions, automatic stock deduction and automatic invoice calculation are enforced on the server.

## 2. Problem Statement
Many small and medium garages still use paper job cards, phone calls and spreadsheets. This causes double bookings, lost vehicle history, wrong stock counts, billing mistakes and no way for customers to know the status of their car. A single integrated system is needed so that customers, mechanics and owners work from the same, always-current data.

## 3. Objectives
- Let customers book and track services online without visiting or calling the garage.
- Give mechanics a digital job card (notes, labour, spare parts, status).
- Give the admin one place to manage people, services, stock, billing and reports.
- Prevent double booking of mechanics and duplicate vehicle registration numbers.
- Keep stock accurate by reducing inventory automatically and warning about low stock.
- Calculate invoices automatically (service + labour + parts + tax) and record payments.
- Provide secure, role-based access using JWT and BCrypt password hashing.

## 4. Existing System
Manual or semi-manual: appointment diary, handwritten job cards, a stock register and a calculator for bills. Drawbacks: no real-time status for customers, easy to double book, stock mismatches, no history search, billing errors, no analytics, no access control, paper records can be lost.

## 5. Proposed System
A three-tier web application. React single-page app (presentation) calls REST APIs of a Spring Boot application (business logic and security), which stores data in MySQL through JPA/Hibernate. Three roles (Customer, Mechanic, Admin) see only their own screens and can call only their own APIs. The complete workflow is automated from booking to feedback.

Advantages: 24x7 booking, live tracking, no double booking, automatic billing, up-to-date stock, complete service history, dashboards and reports, secure access.

## 6. Functional Requirements
| ID | Requirement |
|---|---|
| FR1 | Customer registration, login, profile update |
| FR2 | Customer adds, edits, deletes multiple vehicles; duplicate registration numbers rejected |
| FR3 | Customer views services and books an appointment with date, time and problem description |
| FR4 | Admin reviews, approves or cancels appointments and assigns a mechanic |
| FR5 | System prevents the same mechanic from being booked in the same slot twice |
| FR6 | Mechanic views assigned jobs, customer/vehicle details, vehicle history |
| FR7 | Mechanic adds inspection notes, labour charge, estimated completion date and spare parts |
| FR8 | Mechanic updates status: In Progress, Waiting for Parts, Completed |
| FR9 | Inventory decreases automatically when a part is used; low-stock warning is shown |
| FR10 | Invoice is generated automatically when a job completes (subtotal + labour + parts + 18% GST) |
| FR11 | Customer/admin view and print/download invoices; payment by CASH, CARD, UPI, ONLINE (simulated) |
| FR12 | Customer submits rating and feedback after completion; admin views feedback |
| FR13 | Admin manages customers, mechanics (block/delete), vehicles, services, spare parts |
| FR14 | Dashboards for all roles; admin charts and reports with CSV export |
| FR15 | Only valid status transitions are allowed |

## 7. Non-Functional Requirements
- **Security:** BCrypt passwords, signed JWT, role-based authorisation on every API, CORS restricted to the front end.
- **Performance:** typical API responses under one second for garage-scale data.
- **Usability:** responsive dark UI, form validation with clear messages, loading and error states.
- **Reliability:** transactional service methods; database constraints (unique, foreign keys).
- **Maintainability:** layered architecture (controller, service, repository, entity, dto), DTOs instead of entities.
- **Portability:** runs on Windows, Linux, macOS with Java, Node and MySQL.
- **Scalability:** stateless backend (JWT), so it can run behind a load balancer.

## 8. Software Requirements
Java 17+, Spring Boot 3.3, Spring MVC, Spring Data JPA (Hibernate), Spring Security, JJWT 0.12, Maven, MySQL 8, Node.js 18+, React 18, Vite, Bootstrap 5, Axios, React Router 6, Recharts, Three.js, VS Code or IntelliJ IDEA, MySQL Workbench, Postman, Git/GitHub.

## 9. Hardware Requirements
Development: dual-core 2 GHz CPU or better, 8 GB RAM (4 GB minimum), 2 GB free disk, network access. Deployment: any server or VM with 2 vCPU, 4 GB RAM.

## 10. System Architecture
```
 Browser (React SPA)  ──HTTPS/JSON + JWT──►  Spring Boot REST API  ──JPA/Hibernate──►  MySQL
   pages, layouts,                           Security filter (JWT)
   Axios, Router,                            Controller → Service → Repository
   Three.js hero                             Global exception handler (@ControllerAdvice)
```
Request flow: Axios adds `Authorization: Bearer <token>` → `JwtAuthFilter` validates the token and loads the user → `@PreAuthorize` checks the role → controller validates the DTO (`@Valid`) → service applies business rules inside a transaction → repository reads/writes MySQL → entity is mapped to a response DTO → JSON returned. Any exception is turned into a consistent JSON error by `GlobalExceptionHandler`.

Backend package layout (`com.garage.management`): `controller`, `service`, `repository`, `entity`, `dto`, `security`, `exception`, `config`, `util`.

## 11. ER Diagram Description
Entities and relationships:
- **User** (role CUSTOMER / MECHANIC / ADMIN) 1 ─── * **Vehicle** (owner).
- **User** (customer) 1 ─── * **Appointment**; **Vehicle** 1 ─── * Appointment; **GarageService** 1 ─── * Appointment.
- **Appointment** 1 ─── 1 **ServiceRequest** (the job card).
- **Vehicle** 1 ─── * ServiceRequest; **GarageService** 1 ─── * ServiceRequest; **User** (mechanic) 1 ─── * ServiceRequest.
- **ServiceRequest** * ─── * **SparePart** through **UsedPart** (quantity and unit price captured).
- **ServiceRequest** 1 ─── 1 **Invoice**; **Invoice** 1 ─── 1 **Payment**.
- **ServiceRequest** 1 ─── 1 **Feedback**; **User** (customer) 1 ─── * Feedback.

## 12. Database Schema
Tables: `users`, `vehicles`, `garage_services`, `spare_parts`, `appointments`, `service_requests`, `used_parts`, `invoices`, `payments`, `feedback`. Full DDL with keys and constraints is in `database/schema.sql`. Key constraints: unique `users.email`, unique `vehicles.registration_number`, unique `spare_parts.part_number`, unique `service_requests.appointment_id`, `invoices.service_request_id`, `payments.invoice_id` and `feedback.service_request_id` (enforcing one-to-one), and foreign keys on all relationships.

## 13. Use-Case Diagram Description
Actors: Customer, Mechanic, Admin, (System for automatic actions).
- **Customer:** register/login, manage profile, manage vehicles, view services, book appointment, cancel appointment, track service, view history, view invoice, pay, give feedback.
- **Mechanic:** login, view assigned jobs, view customer and vehicle details, view vehicle history, add inspection notes, add labour, add spare parts, update status, mark completed.
- **Admin:** login, view dashboard, manage customers/mechanics/vehicles/services/inventory, review and approve appointments, assign mechanic, change status, manage invoices and payments, view feedback, generate reports, block/delete users.
- **System:** deduct stock, raise low-stock warning, generate invoice, block double booking, validate transitions.

## 14. Data-Flow Diagram Description
**Level 0:** Customer, Mechanic and Admin exchange data with the single process "Garage Management System", which reads and writes the database.
**Level 1 processes:** 1.0 Authentication, 2.0 Vehicle & Customer Management, 3.0 Appointment & Assignment, 4.0 Service Execution (notes, labour, parts, status), 5.0 Inventory, 6.0 Billing & Payment, 7.0 Feedback, 8.0 Reports & Dashboard.
**Data stores:** D1 Users, D2 Vehicles, D3 Services, D4 Appointments/Service requests, D5 Spare parts, D6 Invoices/Payments, D7 Feedback.
**Main flow:** Customer → (booking details) → 3.0 → D4; Admin → (approve/assign) → 3.0 → D4; Mechanic → (work details, parts) → 4.0 → D4, 5.0 → D5; completion → 6.0 → D6; Customer → (payment) → 6.0 → D6; Customer → (rating) → 7.0 → D7; 8.0 reads D1 to D7 and shows results to Admin.

## 15. API Documentation
See `docs/API_DOCUMENTATION.md` (all endpoints, roles, request/response examples) and the Postman collection in `postman/`.

## 16. Testing Strategy
| Level | What is tested | How |
|---|---|---|
| Unit | Status transition rules (`ServiceStatus.canMoveTo`), invoice maths, validation patterns | JUnit 5 |
| Integration | Controllers + security + MySQL (register/login, booking, assignment, parts, invoice, payment) | Spring Boot Test + MockMvc |
| API | Every endpoint, positive and negative cases, 401/403/409 | Postman collection |
| UI | Forms, validation messages, navigation per role | Manual test cases (table below) |
| Security | Missing token, wrong role, blocked user, tampered token | Postman / manual |

Sample manual test cases: (1) register with weak password → error; (2) add vehicle with existing registration → duplicate error; (3) book on Sunday or a past date → rejected; (4) assign same mechanic to same slot twice → rejected; (5) mark PENDING job as COMPLETED → rejected; (6) add more parts than stock → rejected; (7) complete job → invoice with correct total; (8) pay invoice twice → rejected; (9) customer opens admin URL → redirected; (10) blocked user logs in → access denied.

## 17. Future Enhancements
Real payment gateway (Razorpay/Stripe), SMS/e-mail/WhatsApp notifications, PDF generation on the server, pickup-and-drop scheduling, service reminders by kilometres, mobile app, multi-branch support, supplier and purchase-order module, refresh tokens, audit logs, AI-based fault suggestions.

## 18. Conclusion
The system replaces manual garage work with an integrated, secure and auditable platform. It demonstrates layered Spring Boot architecture, JPA relationships, JWT security, role-based access, business-rule enforcement and a modern React interface, and it covers the entire service life cycle from booking to feedback.

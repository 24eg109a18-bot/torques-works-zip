# Prompt: Animated 3D website + 3D developer portfolio

Copy everything inside the block below into any AI coding assistant.

```
You are a senior creative front-end engineer. Build a modern, animated, 3D personal portfolio website for a web developer.

TECH
- React + Vite, Three.js (use @react-three/fiber and @react-three/drei if available), GSAP + ScrollTrigger (or Framer Motion), Lenis for smooth scrolling, plain CSS variables (or Tailwind).
- Fully responsive (mobile first), 90+ Lighthouse performance, keyboard accessible, respects prefers-reduced-motion.

DESIGN LANGUAGE
- Dark, futuristic, minimal. Background #0b0d12 with soft radial gradients (violet #7c5cff, cyan #22d3ee, warm accent #ffb454).
- Glassmorphism cards: rgba(255,255,255,.05) fill, 14px backdrop blur, 1px translucent border, soft shadow.
- Typography: a condensed display font for headings (Barlow Condensed / Space Grotesk) and a clean sans for body. Large, confident headings, generous spacing.
- Subtle noise/grain overlay, custom cursor with magnetic hover on buttons, micro-animations on every interactive element.

SECTIONS
1. Hero (full viewport): a rotating, floating 3D avatar (low-poly stylised developer bust or a glossy abstract character) in the centre-right, slowly rotating and following the mouse with easing. Left side: small "Available for work" pill, big headline "Hi, I'm <Name>, a web developer who builds fast, beautiful products", one-line intro, two CTA buttons ("View projects" primary, "Contact me" ghost). Floating glass chips around the avatar (React, Node, Three.js) that bob gently. Scroll hint at the bottom.
2. About: short bio, photo card with tilt-on-hover, three animated counters (years, projects, clients).
3. Skills: grid of glass cards grouped by Frontend / Backend / Tools with animated progress rings or an orbiting 3D skill sphere; hover lifts a card and shows a tooltip.
4. Projects: 4-6 project cards with large preview image, tags, "Live" and "Code" links. Cards tilt in 3D toward the cursor, with a glare effect; horizontal pinned scroll on desktop, vertical stack on mobile. Clicking opens a modal with details.
5. Experience/timeline (optional): vertical line that draws as you scroll.
6. Contact: glass form (name, email, message) with validation and success animation, plus social icons that float on hover. Footer with back-to-top.

MOTION
- Lenis smooth scrolling; parallax layers (background glows and floating shapes move at different speeds).
- Section reveal animations (fade + 24px rise, staggered children), animated gradient borders, hover glows.
- Navbar becomes a blurred glass bar on scroll and highlights the active section.
- Page-load intro: logo draw-in then the hero stagger.
- Keep the 3D scene light: <150k triangles, DPR capped at 2, pause rendering when the tab is hidden or the canvas is off screen, dispose geometries on unmount.

DELIVERABLES
- Full source code in a clean folder structure (components/, sections/, hooks/, styles/, assets/), README with run instructions, and a short explanation of how each animation works.
- Replace placeholder content with clearly marked fields (name, role, projects, links) in a single data file.
```

## Short version
"Create a modern animated 3D website: dark futuristic theme, glassmorphism UI, soft gradients, smooth scrolling, a hero section with a floating, rotating 3D object/avatar, parallax scroll, hover micro-animations, projects/skills/contact sections, fully responsive and fast."

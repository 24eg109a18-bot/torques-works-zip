# API Documentation

Base URL: `http://localhost:8080/api`. All endpoints except those marked **Public** need the header
`Authorization: Bearer <JWT>`. Errors always look like:
```json
{ "timestamp": "2026-10-10T10:15:30", "status": 400, "error": "Bad Request",
  "message": "Mechanic is already booked on 2026-10-12 at 10:00. Choose another mechanic.", "path": "/api/service-requests/4/assign", "fieldErrors": null }
```
Status codes: 200/201 success, 204 deleted, 400 validation or business rule, 401 not logged in, 403 not allowed, 404 not found, 409 duplicate.

## Authentication
| Method | Endpoint | Role | Description |
|---|---|---|---|
| POST | /auth/register | Public | Register a customer, returns JWT + user |
| POST | /auth/login | Public | Login (any role), returns JWT + user |
| GET | /auth/me | Any | Current user |

## Customers / Mechanics
| Method | Endpoint | Role |
|---|---|---|
| GET | /customers | ADMIN |
| GET, PUT | /customers/{id} | ADMIN or the customer himself |
| PUT | /customers/{id}/block | ADMIN (toggle block/unblock) |
| DELETE | /customers/{id} | ADMIN |
| GET, POST | /mechanics | ADMIN |
| GET, PUT, DELETE | /mechanics/{id} | ADMIN |
| PUT | /mechanics/{id}/block | ADMIN |

## Vehicles, Services, Spare parts
| Method | Endpoint | Role |
|---|---|---|
| GET | /vehicles | ADMIN (all) / CUSTOMER (own) |
| POST | /vehicles | CUSTOMER |
| GET, PUT, DELETE | /vehicles/{id} | owner or ADMIN |
| GET | /services/public | Public (active services) |
| GET | /services | Any logged in |
| POST, PUT, DELETE | /services, /services/{id} | ADMIN |
| GET | /spare-parts, /spare-parts/low-stock | ADMIN, MECHANIC / ADMIN |
| POST, PUT, DELETE | /spare-parts, /spare-parts/{id} | ADMIN |

## Appointments & Service requests
| Method | Endpoint | Role | Description |
|---|---|---|---|
| POST | /appointments | CUSTOMER | Book (creates a PENDING job card) |
| GET | /appointments | ADMIN / CUSTOMER | List |
| PUT | /appointments/{id}/status | ADMIN / CUSTOMER | Approve / cancel (valid transitions only) |
| GET | /service-requests | Any | Role-filtered list |
| GET | /service-requests/{id} | Allowed party | Details with parts and `allowedNext` |
| GET | /service-requests/vehicle/{vehicleId}/history | Any | Completed jobs of a vehicle |
| PUT | /service-requests/{id}/assign | ADMIN | `{ "mechanicId": 2 }` (double-booking check) |
| PUT | /service-requests/{id}/status | ADMIN / MECHANIC / CUSTOMER | `{ "status": "IN_PROGRESS" }` |
| PUT | /service-requests/{id}/work | MECHANIC / ADMIN | notes, labour, estimated date |
| POST | /service-requests/{id}/parts | MECHANIC / ADMIN | `{ "partId": 1, "quantity": 2 }`, stock decreases |
| DELETE | /service-requests/{id}/parts/{usedPartId} | MECHANIC / ADMIN | stock restored |

Status flow: `PENDING → APPROVED → ASSIGNED → IN_PROGRESS ⇄ WAITING_FOR_PARTS → COMPLETED`; `CANCELLED` possible before completion.

## Invoices, Payments, Feedback, Dashboards
| Method | Endpoint | Role |
|---|---|---|
| GET | /invoices, /invoices/{id} | ADMIN / CUSTOMER (own) |
| POST | /invoices | ADMIN `{ "serviceRequestId": 5 }` (normally automatic on completion) |
| GET, POST | /payments | ADMIN / CUSTOMER. POST `{ "invoiceId": 3, "method": "UPI" }` |
| GET | /feedback | ADMIN (all) / CUSTOMER (own) |
| POST | /feedback | CUSTOMER `{ "serviceRequestId": 5, "rating": 5, "comment": "Great" }` |
| GET | /dashboard/admin, /dashboard/customer, /dashboard/mechanic | respective role |
| GET | /reports/summary | ADMIN |

## Postman / curl examples
```bash
# 1. Login (returns token)
curl -X POST http://localhost:8080/api/auth/login -H "Content-Type: application/json" \
  -d '{"email":"admin@garage.com","password":"Admin@123"}'

# 2. Register a customer
curl -X POST http://localhost:8080/api/auth/register -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@example.com","password":"Test@1234","phone":"9876501234","address":"Hyderabad"}'

# 3. Add a vehicle (customer token)
curl -X POST http://localhost:8080/api/vehicles -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"registrationNumber":"TS12AB4567","brand":"Hyundai","model":"i20","variant":"Asta","manufacturingYear":2021,"fuelType":"Petrol","currentKm":12000,"color":"Red"}'

# 4. Book an appointment (customer token)
curl -X POST http://localhost:8080/api/appointments -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"vehicleId":1,"serviceId":1,"date":"2026-10-20","time":"10:00","problemDescription":"Engine makes noise"}'

# 5. Assign mechanic (admin token)
curl -X PUT http://localhost:8080/api/service-requests/1/assign -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" -d '{"mechanicId":2}'

# 6. Pay an invoice (customer token)
curl -X POST http://localhost:8080/api/payments -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" -d '{"invoiceId":1,"method":"UPI"}'
```
Security checks to demonstrate: calling `/api/customers` with a customer token returns **403**; calling any API without a token returns **401**;
duplicate vehicle registration returns **409**; invalid status change (e.g. PENDING → COMPLETED) returns **400**.

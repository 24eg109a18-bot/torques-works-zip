# Viva Guide: how to explain this project

## 30-second pitch
"This is a full-stack garage management system. Customers book car services online, the admin approves and assigns a mechanic, the mechanic records the work and parts, the system automatically creates the invoice, and the customer pays and gives feedback. Frontend is React, backend is Spring Boot with JWT security, database is MySQL."

## Architecture in one minute
React → Axios (adds JWT) → Spring Boot (Security filter → Controller → Service → Repository) → MySQL.
Controllers only handle HTTP, **services** hold business rules, **repositories** talk to the DB, **DTOs** are what the API returns (entities are never exposed), `GlobalExceptionHandler` makes all errors look the same.

## Where each requirement lives (show these files)
| Topic | File |
|---|---|
| JWT creation / validation | `security/JwtUtil.java`, `security/JwtAuthFilter.java` |
| Role-based access | `config/SecurityConfig.java` + `@PreAuthorize` in controllers |
| BCrypt | `SecurityConfig.passwordEncoder()`, `AuthService.register` |
| Status rules | `entity/ServiceStatus.java` (`next()`), `ServiceRequestService.changeStatus` |
| Double-booking prevention | `ServiceRequestRepository.mechanicBusy`, `ServiceRequestService.assign` |
| Duplicate vehicle | `VehicleService.create` + unique column in `Vehicle.java` |
| Auto stock decrease / low stock | `ServiceRequestService.addPart`, `SparePart.isLowStock`, `InventoryService` |
| Invoice calculation | `InvoiceService.generateFor` |
| Simulated payment | `PaymentService.pay` |
| Many-to-many (request ↔ parts) | `ServiceRequest.usedParts` + `UsedPart` entity |
| Global exception handling | `exception/GlobalExceptionHandler.java` |
| Dashboard statistics | `DashboardService.java` |
| Frontend route protection | `components/ProtectedRoute.jsx`, `App.jsx` |
| Axios + token | `services/api.js` |
| 3D car animation | `components/CarHero3D.jsx` (Three.js, only primitive shapes) |

## Likely questions and answers
**Q: How does login work?** The user posts email and password. Spring's `AuthenticationManager` checks the BCrypt hash. If correct, `JwtUtil` signs a token containing email and role. React stores it and Axios sends it in the `Authorization` header on every call. `JwtAuthFilter` validates it on each request.

**Q: Why JWT and not sessions?** Stateless: the server stores nothing per user, so it scales easily and works well with a separate React front end.

**Q: Why DTOs?** To avoid exposing database entities, avoid lazy-loading and circular JSON problems, and control exactly which fields leave the server (for example the password hash never leaves).

**Q: How do you stop a customer calling admin APIs?** Two layers: the React `ProtectedRoute` hides pages, and the real protection is the backend `@PreAuthorize("hasRole('ADMIN')")`. Calling with a customer token returns 403.

**Q: How is double booking prevented?** When the admin assigns a mechanic, a query checks whether this mechanic already has an assigned or in-progress job on the same date and time. If yes, `InvalidAppointmentException` returns a 400 message.

**Q: How are invalid status changes prevented?** `ServiceStatus.next()` lists the allowed next statuses of each status; the service rejects anything else. Each role is also limited (customer can only cancel, mechanic can only set in-progress / waiting / completed).

**Q: How is the many-to-many relation done?** A service request uses many parts and a part is used in many requests. I used a join entity `UsedPart` because it also stores quantity and the unit price at that time (so old invoices do not change if prices change).

**Q: When is the invoice generated?** Automatically inside `changeStatus` when the mechanic marks the job COMPLETED. Total = service cost + labour + parts + 18% GST.

**Q: Is the payment real?** No, it is simulated as the brief allows. The flow is real: it creates a Payment record with a transaction id and marks the invoice PAID. A gateway such as Razorpay can replace `PaymentService.pay`.

**Q: What does `ddl-auto=update` do?** Hibernate creates or updates tables from the entities at startup, so no manual SQL is required.

**Q: How is the 3D hero made?** With Three.js: a car built from boxes and cylinders, lit by three lights, rotating and hovering, wheels spinning, reacting slightly to the mouse. It is cleaned up on unmount and disabled when the user prefers reduced motion.

## Live demo order (5 minutes)
Customer books → Admin approves + assigns (show double-booking error) → Mechanic notes + parts (stock drops) + completes → invoice appears → Customer pays and rates → Admin dashboard, low stock alert and reports.

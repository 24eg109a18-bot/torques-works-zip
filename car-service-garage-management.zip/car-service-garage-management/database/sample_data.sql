-- =====================================================================
-- OPTIONAL manual sample data (master data only).
-- The application ALSO seeds richer demo data automatically on first start
-- (DataSeeder.java). Only use this file if you want to load data by hand:
--   1. Run the schema first (schema.sql) OR start the backend once with an empty DB
--      and then TRUNCATE the tables, because the seeder skips when users exist.
--   2. mysql -u root -p garage_db < sample_data.sql
-- Passwords are BCrypt hashes:  Admin@123 / Mechanic@123 / Customer@123
-- =====================================================================
USE garage_db;

INSERT INTO users (name,email,password,phone,address,role,specialization,active,created_at) VALUES
('System Admin','admin@garage.com','$2a$10$3YVqBLDYzdmBZk4hrdWPReBsEw2jubEZg.Jz.cn8Xe504CZs9myjm','9876543210','Garage HQ, Hyderabad','ADMIN',NULL,1,NOW()),
('Ravi Kumar','ravi@garage.com','$2a$10$B61yx/cag/PGMy4F6BFA8eSaQ8Z975B14QYxxJQbDpm7Pjp5jdXQu','9000000001','Hyderabad','MECHANIC','Engine & Transmission',1,NOW()),
('Suresh Reddy','suresh@garage.com','$2a$10$B61yx/cag/PGMy4F6BFA8eSaQ8Z975B14QYxxJQbDpm7Pjp5jdXQu','9000000002','Hyderabad','MECHANIC','Brakes & Suspension',1,NOW()),
('Anil Sharma','anil@garage.com','$2a$10$B61yx/cag/PGMy4F6BFA8eSaQ8Z975B14QYxxJQbDpm7Pjp5jdXQu','9000000003','Secunderabad','MECHANIC','AC & Electricals',1,NOW()),
('Rahul Verma','rahul@example.com','$2a$10$5pjUMm6JSCvKHdq.KurP8.CcnyipumegqOT2iwR5J/s8ekWqS3mmO','9123456780','Madhapur, Hyderabad','CUSTOMER',NULL,1,NOW()),
('Priya Nair','priya@example.com','$2a$10$5pjUMm6JSCvKHdq.KurP8.CcnyipumegqOT2iwR5J/s8ekWqS3mmO','9123456781','Gachibowli, Hyderabad','CUSTOMER',NULL,1,NOW()),
('Amit Singh','amit@example.com','$2a$10$5pjUMm6JSCvKHdq.KurP8.CcnyipumegqOT2iwR5J/s8ekWqS3mmO','9123456782','Kukatpally, Hyderabad','CUSTOMER',NULL,1,NOW());

INSERT INTO vehicles (registration_number,brand,model,variant,manufacturing_year,fuel_type,current_km,color,insurance_expiry,rc_number,owner_id) VALUES
('TS09EB1234','Maruti Suzuki','Swift','VXi',2019,'Petrol',42000,'White','2027-06-30','RC-TS-0001',(SELECT id FROM users WHERE email='rahul@example.com')),
('TS08FG5678','Hyundai','Creta','SX',2021,'Diesel',28000,'Black','2027-01-15','RC-TS-0002',(SELECT id FROM users WHERE email='rahul@example.com')),
('AP28CD4321','Honda','City','ZX',2018,'Petrol',61000,'Silver','2026-12-01','RC-AP-0003',(SELECT id FROM users WHERE email='priya@example.com')),
('TS10HJ7788','Tata','Nexon','XZ+',2022,'Petrol',15000,'Blue','2027-08-20','RC-TS-0004',(SELECT id FROM users WHERE email='amit@example.com'));

INSERT INTO garage_services (name,description,estimated_cost,estimated_duration_hours,active) VALUES
('General Service','Complete periodic service: oil, filters, fluids and 40-point check.',2999,3,1),
('Oil Change','Engine oil and oil filter replacement.',1499,1,1),
('Brake Service','Brake pad / disc inspection, cleaning and replacement.',3499,3,1),
('AC Service','AC gas refill, filter cleaning and cooling check.',2499,2,1),
('Engine Service','Engine diagnostics, tuning and repair.',8999,8,1),
('Wheel Alignment','Computerised wheel alignment and balancing.',899,1,1),
('Battery Replacement','Battery testing and replacement with warranty.',1200,1,1),
('Tyre Replacement','Tyre fitting, balancing and disposal of old tyres.',800,2,1),
('Denting & Painting','Body denting, colour matching and painting.',12000,24,1),
('Full Inspection','Complete vehicle inspection with detailed report.',999,2,1);

INSERT INTO spare_parts (name,part_number,brand,category,price,quantity,min_stock_level) VALUES
('Engine Oil 5W-30 (1L)','OIL-5W30-1L','Castrol','Lubricants',650,40,10),
('Oil Filter','FLT-OIL-001','Bosch','Filters',250,30,10),
('Air Filter','FLT-AIR-002','Bosch','Filters',350,25,8),
('Brake Pad Set (Front)','BRK-PAD-F01','Bosch','Brakes',1800,12,5),
('Brake Disc','BRK-DSC-002','Brembo','Brakes',2200,4,5),
('Spark Plug','IGN-SPK-001','NGK','Ignition',300,40,10),
('AC Compressor','AC-CMP-001','Denso','AC',9500,2,3),
('AC Gas R134a','AC-GAS-134','Generic','AC',500,15,5),
('Car Battery 12V 45Ah','BAT-12V-45','Exide','Electrical',4800,6,3),
('Clutch Plate','CLT-PLT-002','Valeo','Transmission',3200,3,4);

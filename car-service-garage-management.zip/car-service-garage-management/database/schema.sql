-- =====================================================================
-- Car Service & Garage Management System : MySQL schema
-- NOTE: the Spring Boot app creates/updates these tables automatically
-- (spring.jpa.hibernate.ddl-auto=update). This file documents the schema
-- and can be run manually in MySQL Workbench if you prefer.
-- =====================================================================
CREATE DATABASE IF NOT EXISTS garage_db;
USE garage_db;

CREATE TABLE users (
  id             BIGINT AUTO_INCREMENT PRIMARY KEY,
  name           VARCHAR(100) NOT NULL,
  email          VARCHAR(150) NOT NULL UNIQUE,
  password       VARCHAR(255) NOT NULL,            -- BCrypt hash
  phone          VARCHAR(15),
  address        VARCHAR(255),
  role           VARCHAR(20)  NOT NULL,            -- CUSTOMER | MECHANIC | ADMIN
  specialization VARCHAR(255),
  active         BIT NOT NULL DEFAULT 1,           -- 0 = blocked
  created_at     DATETIME(6)
);

CREATE TABLE vehicles (
  id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
  registration_number VARCHAR(20) NOT NULL UNIQUE,  -- duplicate registration numbers prevented
  brand               VARCHAR(255) NOT NULL,
  model               VARCHAR(255) NOT NULL,
  variant             VARCHAR(255),
  manufacturing_year  INT,
  fuel_type           VARCHAR(255),
  current_km          INT,
  color               VARCHAR(255),
  insurance_expiry    DATE,
  rc_number           VARCHAR(255),
  owner_id            BIGINT NOT NULL,
  CONSTRAINT fk_vehicle_owner FOREIGN KEY (owner_id) REFERENCES users(id)
);

CREATE TABLE garage_services (
  id                       BIGINT AUTO_INCREMENT PRIMARY KEY,
  name                     VARCHAR(100) NOT NULL UNIQUE,
  description              VARCHAR(500),
  estimated_cost           DECIMAL(12,2) NOT NULL,
  estimated_duration_hours INT NOT NULL,
  active                   BIT NOT NULL DEFAULT 1
);

CREATE TABLE spare_parts (
  id              BIGINT AUTO_INCREMENT PRIMARY KEY,
  name            VARCHAR(255) NOT NULL,
  part_number     VARCHAR(50)  NOT NULL UNIQUE,
  brand           VARCHAR(255),
  category        VARCHAR(255),
  price           DECIMAL(12,2) NOT NULL,
  quantity        INT NOT NULL,
  min_stock_level INT NOT NULL
);

CREATE TABLE appointments (
  id                  BIGINT AUTO_INCREMENT PRIMARY KEY,
  customer_id         BIGINT NOT NULL,
  vehicle_id          BIGINT NOT NULL,
  service_id          BIGINT NOT NULL,
  appointment_date    DATE NOT NULL,
  appointment_time    TIME NOT NULL,
  problem_description VARCHAR(1000),
  status              VARCHAR(30) NOT NULL,
  created_at          DATETIME(6),
  CONSTRAINT fk_appt_customer FOREIGN KEY (customer_id) REFERENCES users(id),
  CONSTRAINT fk_appt_vehicle  FOREIGN KEY (vehicle_id)  REFERENCES vehicles(id),
  CONSTRAINT fk_appt_service  FOREIGN KEY (service_id)  REFERENCES garage_services(id)
);

CREATE TABLE service_requests (
  id                         BIGINT AUTO_INCREMENT PRIMARY KEY,
  appointment_id             BIGINT NOT NULL UNIQUE,   -- one-to-one with appointment
  vehicle_id                 BIGINT NOT NULL,
  service_id                 BIGINT NOT NULL,
  mechanic_id                BIGINT NULL,
  status                     VARCHAR(30) NOT NULL,
  inspection_notes           TEXT,
  labour_charge              DECIMAL(12,2) NOT NULL DEFAULT 0,
  estimated_completion_date  DATE,
  created_at                 DATETIME(6),
  completed_at               DATETIME(6),
  CONSTRAINT fk_sr_appointment FOREIGN KEY (appointment_id) REFERENCES appointments(id),
  CONSTRAINT fk_sr_vehicle     FOREIGN KEY (vehicle_id)     REFERENCES vehicles(id),
  CONSTRAINT fk_sr_service     FOREIGN KEY (service_id)     REFERENCES garage_services(id),
  CONSTRAINT fk_sr_mechanic    FOREIGN KEY (mechanic_id)    REFERENCES users(id)
);

-- Many-to-many: service_requests <-> spare_parts (with quantity and price snapshot)
CREATE TABLE used_parts (
  id                 BIGINT AUTO_INCREMENT PRIMARY KEY,
  service_request_id BIGINT NOT NULL,
  spare_part_id      BIGINT NOT NULL,
  quantity           INT NOT NULL,
  unit_price         DECIMAL(12,2) NOT NULL,
  CONSTRAINT fk_up_request FOREIGN KEY (service_request_id) REFERENCES service_requests(id),
  CONSTRAINT fk_up_part    FOREIGN KEY (spare_part_id)      REFERENCES spare_parts(id)
);

CREATE TABLE invoices (
  id                 BIGINT AUTO_INCREMENT PRIMARY KEY,
  invoice_number     VARCHAR(40) NOT NULL UNIQUE,
  service_request_id BIGINT NOT NULL UNIQUE,           -- one-to-one with service request
  invoice_date       DATE NOT NULL,
  subtotal           DECIMAL(12,2) NOT NULL,
  labour_charge      DECIMAL(12,2) NOT NULL,
  parts_cost         DECIMAL(12,2) NOT NULL,
  tax                DECIMAL(12,2) NOT NULL,
  total              DECIMAL(12,2) NOT NULL,
  payment_status     VARCHAR(20) NOT NULL,
  CONSTRAINT fk_inv_request FOREIGN KEY (service_request_id) REFERENCES service_requests(id)
);

CREATE TABLE payments (
  id             BIGINT AUTO_INCREMENT PRIMARY KEY,
  invoice_id     BIGINT NOT NULL UNIQUE,               -- one-to-one with invoice
  amount         DECIMAL(12,2) NOT NULL,
  method         VARCHAR(20) NOT NULL,                 -- CASH | CARD | UPI | ONLINE
  payment_date   DATETIME(6) NOT NULL,
  transaction_id VARCHAR(50) NOT NULL,
  status         VARCHAR(20) NOT NULL,
  CONSTRAINT fk_pay_invoice FOREIGN KEY (invoice_id) REFERENCES invoices(id)
);

CREATE TABLE feedback (
  id                 BIGINT AUTO_INCREMENT PRIMARY KEY,
  service_request_id BIGINT NOT NULL UNIQUE,
  customer_id        BIGINT NOT NULL,
  rating             INT NOT NULL,
  comment            VARCHAR(1000),
  created_at         DATETIME(6),
  CONSTRAINT fk_fb_request  FOREIGN KEY (service_request_id) REFERENCES service_requests(id),
  CONSTRAINT fk_fb_customer FOREIGN KEY (customer_id)        REFERENCES users(id)
);

import { Route, Routes } from 'react-router-dom';
import ProtectedRoute from './components/ProtectedRoute';
import PublicLayout from './layouts/PublicLayout';
import DashboardLayout from './layouts/DashboardLayout';

import Home from './pages/public/Home';
import About from './pages/public/About';
import Services from './pages/public/Services';
import Contact from './pages/public/Contact';
import Login from './pages/public/Login';
import Register from './pages/public/Register';
import NotFound from './pages/public/NotFound';

import CustomerDashboard from './pages/customer/CustomerDashboard';
import Profile from './pages/customer/Profile';
import MyVehicles from './pages/customer/MyVehicles';
import VehicleForm from './pages/customer/VehicleForm';
import BookService from './pages/customer/BookService';
import MyAppointments from './pages/customer/MyAppointments';
import ServiceTracking from './pages/customer/ServiceTracking';
import ServiceHistory from './pages/customer/ServiceHistory';
import MyInvoices from './pages/customer/MyInvoices';
import InvoiceView from './pages/shared/InvoiceView';
import Payment from './pages/customer/Payment';
import Feedback from './pages/customer/Feedback';

import MechanicDashboard from './pages/mechanic/MechanicDashboard';
import AssignedServices from './pages/mechanic/AssignedServices';
import ServiceDetails from './pages/mechanic/ServiceDetails';
import CompletedServices from './pages/mechanic/CompletedServices';

import AdminDashboard from './pages/admin/AdminDashboard';
import AdminCustomers from './pages/admin/AdminCustomers';
import AdminMechanics from './pages/admin/AdminMechanics';
import AdminVehicles from './pages/admin/AdminVehicles';
import AdminServices from './pages/admin/AdminServices';
import AdminAppointments from './pages/admin/AdminAppointments';
import AdminServiceRequests from './pages/admin/AdminServiceRequests';
import AdminInventory from './pages/admin/AdminInventory';
import AdminInvoices from './pages/admin/AdminInvoices';
import AdminPayments from './pages/admin/AdminPayments';
import AdminReports from './pages/admin/AdminReports';
import AdminFeedback from './pages/admin/AdminFeedback';

export default function App() {
  return (
    <Routes>
      <Route element={<PublicLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Route>

      <Route path="/customer" element={<ProtectedRoute roles={['CUSTOMER']}><DashboardLayout role="CUSTOMER" /></ProtectedRoute>}>
        <Route index element={<CustomerDashboard />} />
        <Route path="profile" element={<Profile />} />
        <Route path="vehicles" element={<MyVehicles />} />
        <Route path="vehicles/new" element={<VehicleForm />} />
        <Route path="vehicles/:id/edit" element={<VehicleForm />} />
        <Route path="book" element={<BookService />} />
        <Route path="appointments" element={<MyAppointments />} />
        <Route path="tracking" element={<ServiceTracking />} />
        <Route path="history" element={<ServiceHistory />} />
        <Route path="invoices" element={<MyInvoices />} />
        <Route path="invoices/:id" element={<InvoiceView backTo="/customer/invoices" />} />
        <Route path="payment" element={<Payment />} />
        <Route path="feedback" element={<Feedback />} />
      </Route>

      <Route path="/mechanic" element={<ProtectedRoute roles={['MECHANIC']}><DashboardLayout role="MECHANIC" /></ProtectedRoute>}>
        <Route index element={<MechanicDashboard />} />
        <Route path="services" element={<AssignedServices />} />
        <Route path="services/:id" element={<ServiceDetails />} />
        <Route path="completed" element={<CompletedServices />} />
      </Route>

      <Route path="/admin" element={<ProtectedRoute roles={['ADMIN']}><DashboardLayout role="ADMIN" /></ProtectedRoute>}>
        <Route index element={<AdminDashboard />} />
        <Route path="customers" element={<AdminCustomers />} />
        <Route path="mechanics" element={<AdminMechanics />} />
        <Route path="vehicles" element={<AdminVehicles />} />
        <Route path="services" element={<AdminServices />} />
        <Route path="appointments" element={<AdminAppointments />} />
        <Route path="service-requests" element={<AdminServiceRequests />} />
        <Route path="inventory" element={<AdminInventory />} />
        <Route path="invoices" element={<AdminInvoices />} />
        <Route path="invoices/:id" element={<InvoiceView backTo="/admin/invoices" />} />
        <Route path="payments" element={<AdminPayments />} />
        <Route path="reports" element={<AdminReports />} />
        <Route path="feedback" element={<AdminFeedback />} />
      </Route>

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

import { Link, NavLink, Outlet } from 'react-router-dom';
import { homePath, useAuth } from '../context/AuthContext';

export default function PublicLayout() {
  const { user } = useAuth();
  return (
    <>
      <header className="site-nav">
        <nav className="container d-flex align-items-center justify-content-between flex-wrap py-2">
          <Link to="/" className="brand"><i className="bi bi-gear-wide-connected"></i>TorqueWorks</Link>
          <div className="d-flex align-items-center flex-wrap gap-1">
            <NavLink to="/" end className="nav-link">Home</NavLink>
            <NavLink to="/about" className="nav-link">About</NavLink>
            <NavLink to="/services" className="nav-link">Services</NavLink>
            <NavLink to="/contact" className="nav-link">Contact</NavLink>
            {user ? (
              <Link to={homePath(user.role)} className="btn btn-accent btn-sm ms-2">My dashboard</Link>
            ) : (
              <>
                <Link to="/login" className="btn btn-ghost btn-sm ms-2">Log in</Link>
                <Link to="/register" className="btn btn-accent btn-sm">Register</Link>
              </>
            )}
          </div>
        </nav>
      </header>
      <main><Outlet /></main>
      <footer className="footer py-4 mt-5">
        <div className="container d-flex justify-content-between flex-wrap gap-2">
          <span>&copy; {new Date().getFullYear()} TorqueWorks Garage. College project: Car Service &amp; Garage Management System.</span>
          <span>Mon-Sat, 9:00 am to 6:00 pm</span>
        </div>
      </footer>
    </>
  );
}

import { useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import ConfirmDialog from '../components/ConfirmDialog';

const MENUS = {
  CUSTOMER: [
    ['/customer', 'Dashboard', 'bi-speedometer2', true],
    ['/customer/book', 'Book Service', 'bi-calendar-plus'],
    ['/customer/appointments', 'My Appointments', 'bi-calendar-check'],
    ['/customer/tracking', 'Service Tracking', 'bi-geo-alt'],
    ['/customer/vehicles', 'My Vehicles', 'bi-car-front'],
    ['/customer/history', 'Service History', 'bi-clock-history'],
    ['/customer/invoices', 'Invoices', 'bi-receipt'],
    ['/customer/payment', 'Payment', 'bi-credit-card'],
    ['/customer/feedback', 'Feedback', 'bi-star'],
    ['/customer/profile', 'Profile', 'bi-person'],
  ],
  MECHANIC: [
    ['/mechanic', 'Dashboard', 'bi-speedometer2', true],
    ['/mechanic/services', 'Assigned Services', 'bi-wrench-adjustable'],
    ['/mechanic/completed', 'Completed Services', 'bi-check2-circle'],
  ],
  ADMIN: [
    ['/admin', 'Dashboard', 'bi-speedometer2', true],
    ['/admin/appointments', 'Appointments', 'bi-calendar-check'],
    ['/admin/service-requests', 'Service Requests', 'bi-clipboard-check'],
    ['/admin/customers', 'Customers', 'bi-people'],
    ['/admin/mechanics', 'Mechanics', 'bi-person-gear'],
    ['/admin/vehicles', 'Vehicles', 'bi-car-front'],
    ['/admin/services', 'Services', 'bi-tools'],
    ['/admin/inventory', 'Inventory', 'bi-box-seam'],
    ['/admin/invoices', 'Invoices', 'bi-receipt'],
    ['/admin/payments', 'Payments', 'bi-cash-coin'],
    ['/admin/feedback', 'Feedback', 'bi-chat-heart'],
    ['/admin/reports', 'Reports', 'bi-bar-chart-line'],
  ],
};

export default function DashboardLayout({ role }) {
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const navigate = useNavigate();
  useLocation(); // re-render on navigation so the mobile menu closes

  return (
    <div className="shell">
      <aside className={`sidebar ${open ? 'open' : ''}`}>
        <Link to="/" className="brand"><i className="bi bi-gear-wide-connected"></i>TorqueWorks</Link>
        <nav onClick={() => setOpen(false)}>
          {MENUS[role].map(([to, text, icon, end]) => (
            <NavLink key={to} to={to} end={end} className="side-link"><i className={`bi ${icon}`}></i>{text}</NavLink>
          ))}
        </nav>
      </aside>

      <div className="main">
        <div className="topbar">
          <button className="btn btn-ghost menu-btn" onClick={() => setOpen(!open)} aria-label="Toggle menu"><i className="bi bi-list"></i></button>
          <div className="muted d-none d-md-block">{role.charAt(0) + role.slice(1).toLowerCase()} panel</div>
          <div className="d-flex align-items-center gap-3">
            <span><i className="bi bi-person-circle me-2"></i>{user?.name}</span>
            <button className="btn btn-ghost btn-sm" onClick={() => setConfirm(true)}><i className="bi bi-box-arrow-right me-1"></i>Log out</button>
          </div>
        </div>
        <div className="content"><Outlet /></div>
      </div>

      <ConfirmDialog
        show={confirm}
        title="Log out"
        message="Do you want to log out of your account?"
        confirmLabel="Log out"
        onCancel={() => setConfirm(false)}
        onConfirm={() => { logout(); navigate('/login'); }}
      />
    </div>
  );
}

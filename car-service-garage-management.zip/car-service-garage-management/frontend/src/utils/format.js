export const money = (n) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(n ?? 0);

const toDate = (d) => new Date(typeof d === 'string' && d.length === 10 ? `${d}T00:00:00` : d);

export const fmtDate = (d) =>
  d ? toDate(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';

export const fmtDateTime = (d) =>
  d ? toDate(d).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—';

export const fmtTime = (t) => (t ? t.slice(0, 5) : '');
export const label = (s) => (s ? s.replaceAll('_', ' ') : '');

/** Today as yyyy-MM-dd in the user's own timezone (used for date input min values). */
export const todayStr = () => {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
};

// Same rules as the backend (see Patterns.java) so users get instant feedback.
export const isEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v || '');
export const isStrongPassword = (v) => /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,64}$/.test(v || '');
export const isPhone = (v) => /^[6-9]\d{9}$/.test(v || '');
export const isRegNo = (v) => /^[A-Z]{2}[ -]?\d{1,2}[ -]?[A-Z]{0,3}[ -]?\d{4}$/i.test(v || '');
export const hasErrors = (errors) => Object.values(errors).some(Boolean);

export const MSG = {
  password: 'Min 8 characters with upper, lower, digit and special character',
  phone: 'Enter a valid 10-digit mobile number',
  email: 'Enter a valid email address',
  regNo: 'Enter a valid registration number, e.g. TS09EB1234',
};

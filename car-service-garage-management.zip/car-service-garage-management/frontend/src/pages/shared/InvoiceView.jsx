import { Link, useParams } from 'react-router-dom';
import { invoicesApi } from '../../services/garageApi';
import useFetch from '../../hooks/useFetch';
import { Async } from '../../components/Loader';
import StatusBadge from '../../components/StatusBadge';
import { fmtDate, fmtDateTime, money } from '../../utils/format';

/** Printable invoice. "Download PDF" uses the browser's print dialog (Save as PDF). */
export default function InvoiceView({ backTo }) {
  const { id } = useParams();
  const { data: i, loading, error, reload } = useFetch(() => invoicesApi.get(id), [id]);
  return (
    <>
      <div className="page-title no-print">
        <Link to={backTo} className="btn btn-ghost btn-sm"><i className="bi bi-arrow-left me-1"></i>Back</Link>
        <button className="btn btn-accent" onClick={() => window.print()}><i className="bi bi-download me-2"></i>Download / Print PDF</button>
      </div>
      <Async loading={loading} error={error} reload={reload}>
        {i && (
          <div className="invoice-sheet">
            <div className="d-flex justify-content-between flex-wrap gap-3 mb-4">
              <div><h2 className="mb-0">TorqueWorks Garage</h2><div className="muted">Plot 21, Auto Nagar, Hyderabad 500070<br />+91 98765 43210 · care@torqueworks.example</div></div>
              <div className="text-md-end"><h4 className="mb-1">TAX INVOICE</h4><div><strong>{i.invoiceNumber}</strong></div><div className="muted">Date: {fmtDate(i.invoiceDate)}</div><div className="mt-1"><StatusBadge status={i.paymentStatus} /></div></div>
            </div>
            <div className="row g-3 mb-4">
              <div className="col-sm-6"><div className="muted small">Billed to</div><strong>{i.customerName}</strong><div>{i.customerEmail}</div><div>{i.customerPhone}</div><div>{i.customerAddress}</div></div>
              <div className="col-sm-6"><div className="muted small">Vehicle</div><strong>{i.vehicleName}</strong><div>Reg. no: {i.vehicleRegistration}</div><div className="muted small mt-2">Service / Mechanic</div><div>{i.serviceName} · {i.mechanicName || '—'}</div></div>
            </div>
            <table className="table">
              <thead><tr><th>Description</th><th className="text-end">Qty</th><th className="text-end">Rate</th><th className="text-end">Amount</th></tr></thead>
              <tbody>
                <tr><td>{i.serviceName} (service charge)</td><td className="text-end">1</td><td className="text-end">{money(i.subtotal)}</td><td className="text-end">{money(i.subtotal)}</td></tr>
                {i.parts.map((p) => <tr key={p.id}><td>{p.partName} <span className="muted small">({p.partNumber})</span></td><td className="text-end">{p.quantity}</td><td className="text-end">{money(p.unitPrice)}</td><td className="text-end">{money(p.lineTotal)}</td></tr>)}
                <tr><td>Labour charges</td><td className="text-end">1</td><td className="text-end">{money(i.labourCharge)}</td><td className="text-end">{money(i.labourCharge)}</td></tr>
              </tbody>
            </table>
            <div className="ms-auto" style={{ maxWidth: 320 }}>
              <div className="d-flex justify-content-between"><span className="muted">Service subtotal</span><span>{money(i.subtotal)}</span></div>
              <div className="d-flex justify-content-between"><span className="muted">Labour charges</span><span>{money(i.labourCharge)}</span></div>
              <div className="d-flex justify-content-between"><span className="muted">Spare parts</span><span>{money(i.partsCost)}</span></div>
              <div className="d-flex justify-content-between"><span className="muted">GST (18%)</span><span>{money(i.tax)}</span></div>
              <hr />
              <div className="d-flex justify-content-between fs-5"><strong>Total</strong><strong>{money(i.total)}</strong></div>
            </div>
            {i.paymentStatus === 'PAID' && <div className="mt-4 muted small">Paid by {i.paymentMethod} on {fmtDateTime(i.paidOn)} · Transaction {i.transactionId}</div>}
            <div className="mt-4 muted small">Thank you for choosing TorqueWorks. This is a computer-generated invoice.</div>
          </div>
        )}
      </Async>
    </>
  );
}

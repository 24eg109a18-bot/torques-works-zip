import { useState } from 'react';
import { feedbackApi, requestsApi } from '../../services/garageApi';
import { errMsg } from '../../services/api';
import useFetch from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import { Async } from '../../components/Loader';
import Field from '../../components/Field';
import DataTable from '../../components/DataTable';
import { fmtDate } from '../../utils/format';

export const Stars = ({ value, onChange }) => (
  <div className="stars" role="radiogroup" aria-label="Rating">
    {[1, 2, 3, 4, 5].map((n) => <button type="button" key={n} className={n <= value ? 'on' : ''} onClick={() => onChange && onChange(n)} aria-label={`${n} star`} disabled={!onChange}>★</button>)}
  </div>
);

export default function Feedback() {
  const reqs = useFetch(() => requestsApi.list());
  const list = useFetch(() => feedbackApi.list());
  const toast = useToast();
  const [form, setForm] = useState({ serviceRequestId: '', rating: 0, comment: '' });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const eligible = (reqs.data || []).filter((r) => r.status === 'COMPLETED' && !r.feedbackGiven);

  const submit = async (e) => {
    e.preventDefault();
    const err = { serviceRequestId: form.serviceRequestId ? '' : 'Select a completed service', rating: form.rating ? '' : 'Choose a rating from 1 to 5 stars' };
    setErrors(err);
    if (err.serviceRequestId || err.rating) return;
    setBusy(true);
    try {
      await feedbackApi.submit({ ...form, serviceRequestId: Number(form.serviceRequestId) });
      toast.success('Thank you for your feedback!');
      setForm({ serviceRequestId: '', rating: 0, comment: '' });
      reqs.reload(); list.reload();
    } catch (ex) { toast.error(errMsg(ex)); } finally { setBusy(false); }
  };
  const columns = [
    { key: 'serviceName', label: 'Service' },
    { key: 'vehicleRegistration', label: 'Vehicle' },
    { key: 'rating', label: 'Rating', render: (f) => <span className="text-warning">{'★'.repeat(f.rating)}<span className="muted">{'★'.repeat(5 - f.rating)}</span></span> },
    { key: 'comment', label: 'Comment' },
    { key: 'createdAt', label: 'Date', render: (f) => fmtDate(f.createdAt) },
  ];
  return (
    <>
      <div className="page-title"><h2>Feedback</h2></div>
      <div className="row g-3">
        <div className="col-lg-5">
          <Async loading={reqs.loading} error={reqs.error} reload={reqs.reload}>
            <form className="panel panel-body" onSubmit={submit} noValidate>
              <h5>Rate a completed service</h5>
              {eligible.length === 0 ? <div className="muted">No completed services are waiting for your feedback.</div> : (
                <>
                  <Field label="Service" error={errors.serviceRequestId}>
                    <select className={`form-select ${errors.serviceRequestId ? 'is-invalid' : ''}`} value={form.serviceRequestId} onChange={(e) => setForm({ ...form, serviceRequestId: e.target.value })}>
                      <option value="">Select service</option>
                      {eligible.map((r) => <option key={r.id} value={r.id}>{r.serviceName} - {r.vehicleRegistration} ({fmtDate(r.appointmentDate)})</option>)}
                    </select>
                  </Field>
                  <Field label="Rating" error={errors.rating}><Stars value={form.rating} onChange={(n) => setForm({ ...form, rating: n })} /></Field>
                  <Field label="Comment (optional)"><textarea rows="3" maxLength={1000} className="form-control" value={form.comment} onChange={(e) => setForm({ ...form, comment: e.target.value })} /></Field>
                  <button className="btn btn-accent" disabled={busy}>{busy && <span className="spinner-border spinner-border-sm me-2"></span>}Submit feedback</button>
                </>
              )}
            </form>
          </Async>
        </div>
        <div className="col-lg-7"><div className="panel panel-body"><h5>My feedback</h5><Async loading={list.loading} error={list.error} reload={list.reload}><DataTable columns={columns} rows={list.data || []} searchable={false} empty="You have not submitted any feedback yet." /></Async></div></div>
      </div>
    </>
  );
}

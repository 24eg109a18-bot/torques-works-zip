import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { vehiclesApi } from '../../services/garageApi';
import { errMsg } from '../../services/api';
import { useToast } from '../../context/ToastContext';
import Field from '../../components/Field';
import Loader from '../../components/Loader';
import { hasErrors, isRegNo, MSG } from '../../utils/validators';

const EMPTY = { registrationNumber: '', brand: '', model: '', variant: '', manufacturingYear: '', fuelType: 'Petrol', currentKm: '', color: '', insuranceExpiry: '', rcNumber: '' };
const FUELS = ['Petrol', 'Diesel', 'CNG', 'Electric', 'Hybrid'];

/** One form for both "Add vehicle" and "Edit vehicle". */
export default function VehicleForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(!!id);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!id) return;
    vehiclesApi.get(id).then((v) => setForm({ ...EMPTY, ...Object.fromEntries(Object.entries(v).map(([k, val]) => [k, val ?? ''])) }))
      .catch((e) => toast.error(errMsg(e))).finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const cls = (k) => `form-control ${errors[k] ? 'is-invalid' : ''}`;
  const year = new Date().getFullYear();

  const submit = async (e) => {
    e.preventDefault();
    const y = Number(form.manufacturingYear);
    const err = {
      registrationNumber: isRegNo(form.registrationNumber) ? '' : MSG.regNo,
      brand: form.brand.trim() ? '' : 'Brand is required',
      model: form.model.trim() ? '' : 'Model is required',
      manufacturingYear: y >= 1980 && y <= year + 1 ? '' : `Enter a year between 1980 and ${year + 1}`,
      currentKm: form.currentKm !== '' && Number(form.currentKm) >= 0 ? '' : 'Enter the odometer reading (0 or more)',
    };
    setErrors(err);
    if (hasErrors(err)) return;
    setBusy(true);
    const body = { ...form, manufacturingYear: y, currentKm: Number(form.currentKm), insuranceExpiry: form.insuranceExpiry || null };
    delete body.id; delete body.ownerId; delete body.ownerName;
    try {
      if (id) await vehiclesApi.update(id, body); else await vehiclesApi.create(body);
      toast.success(id ? 'Vehicle updated' : 'Vehicle added');
      navigate('/customer/vehicles');
    } catch (ex) { toast.error(errMsg(ex)); } finally { setBusy(false); }
  };

  if (loading) return <Loader />;
  return (
    <>
      <div className="page-title"><h2>{id ? 'Edit vehicle' : 'Add vehicle'}</h2></div>
      <form className="panel panel-body" onSubmit={submit} noValidate>
        <div className="row">
          <Field className="col-md-4 mb-3" label="Registration number" error={errors.registrationNumber}><input className={cls('registrationNumber')} placeholder="TS09EB1234" value={form.registrationNumber} onChange={set('registrationNumber')} /></Field>
          <Field className="col-md-4 mb-3" label="Brand" error={errors.brand}><input className={cls('brand')} placeholder="Maruti Suzuki" value={form.brand} onChange={set('brand')} /></Field>
          <Field className="col-md-4 mb-3" label="Model" error={errors.model}><input className={cls('model')} placeholder="Swift" value={form.model} onChange={set('model')} /></Field>
          <Field className="col-md-4 mb-3" label="Variant"><input className="form-control" placeholder="VXi" value={form.variant} onChange={set('variant')} /></Field>
          <Field className="col-md-4 mb-3" label="Manufacturing year" error={errors.manufacturingYear}><input type="number" className={cls('manufacturingYear')} value={form.manufacturingYear} onChange={set('manufacturingYear')} /></Field>
          <Field className="col-md-4 mb-3" label="Fuel type"><select className="form-select" value={form.fuelType} onChange={set('fuelType')}>{FUELS.map((f) => <option key={f}>{f}</option>)}</select></Field>
          <Field className="col-md-4 mb-3" label="Current kilometres" error={errors.currentKm}><input type="number" min="0" className={cls('currentKm')} value={form.currentKm} onChange={set('currentKm')} /></Field>
          <Field className="col-md-4 mb-3" label="Colour"><input className="form-control" value={form.color} onChange={set('color')} /></Field>
          <Field className="col-md-4 mb-3" label="Insurance expiry"><input type="date" className="form-control" value={form.insuranceExpiry} onChange={set('insuranceExpiry')} /></Field>
          <Field className="col-md-4 mb-3" label="RC number"><input className="form-control" value={form.rcNumber} onChange={set('rcNumber')} /></Field>
        </div>
        <div className="d-flex gap-2">
          <button className="btn btn-accent" disabled={busy}>{busy && <span className="spinner-border spinner-border-sm me-2"></span>}{id ? 'Save changes' : 'Add vehicle'}</button>
          <button type="button" className="btn btn-ghost" onClick={() => navigate('/customer/vehicles')}>Cancel</button>
        </div>
      </form>
    </>
  );
}

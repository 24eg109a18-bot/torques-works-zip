import { useState } from 'react';
import { Link } from 'react-router-dom';
import { invoicesApi, paymentsApi } from '../../services/garageApi';
import useFetch from '../../hooks/useFetch';
import { Async } from '../../components/Loader';
import DataTable from '../../components/DataTable';
import PayModal from '../../components/PayModal';
import StatusBadge from '../../components/StatusBadge';
import { fmtDateTime, money } from '../../utils/format';

export default function Payment() {
  const invoices = useFetch(() => invoicesApi.list());
  const payments = useFetch(() => paymentsApi.list());
  const [paying, setPaying] = useState(null);
  const pending = (invoices.data || []).filter((i) => i.paymentStatus === 'PENDING');

  const done = () => { setPaying(null); invoices.reload(); payments.reload(); };
  const historyCols = [
    { key: 'transactionId', label: 'Transaction' },
    { key: 'invoiceNumber', label: 'Invoice' },
    { key: 'amount', label: 'Amount', render: (p) => money(p.amount) },
    { key: 'method', label: 'Method' },
    { key: 'paymentDate', label: 'Date', render: (p) => fmtDateTime(p.paymentDate) },
    { key: 'status', label: 'Status', render: (p) => <StatusBadge status={p.status} /> },
  ];
  return (
    <>
      <div className="page-title"><h2>Payment</h2></div>
      <div className="panel mb-4">
        <div className="panel-head"><h5 className="mb-0">Pending payments</h5></div>
        <div className="panel-body">
          <Async loading={invoices.loading} error={invoices.error} reload={invoices.reload}>
            {pending.length === 0 ? <div className="muted">You have no pending payments.</div> : pending.map((i) => (
              <div key={i.id} className="d-flex justify-content-between align-items-center flex-wrap gap-2 py-2 border-bottom border-secondary-subtle">
                <div><strong>{i.invoiceNumber}</strong> <span className="muted">· {i.serviceName} · {i.vehicleRegistration}</span></div>
                <div className="d-flex align-items-center gap-2"><span className="fs-5 fw-semibold">{money(i.total)}</span>
                  <Link className="btn btn-ghost btn-sm" to={`/customer/invoices/${i.id}`}>View</Link>
                  <button className="btn btn-accent btn-sm" onClick={() => setPaying(i)}>Pay now</button></div>
              </div>
            ))}
          </Async>
        </div>
      </div>
      <div className="panel">
        <div className="panel-head"><h5 className="mb-0">Payment history</h5></div>
        <div className="panel-body"><Async loading={payments.loading} error={payments.error} reload={payments.reload}><DataTable columns={historyCols} rows={payments.data || []} empty="No payments yet." /></Async></div>
      </div>
      {paying && <PayModal invoice={paying} onClose={() => setPaying(null)} onPaid={done} />}
    </>
  );
}

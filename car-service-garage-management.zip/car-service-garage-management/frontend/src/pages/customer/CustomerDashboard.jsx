import { Link } from 'react-router-dom';
import { dashboardApi, requestsApi } from '../../services/garageApi';
import useFetch from '../../hooks/useFetch';
import { Async } from '../../components/Loader';
import StatCard from '../../components/StatCard';
import StatusBadge from '../../components/StatusBadge';
import { fmtDate, fmtTime, money } from '../../utils/format';
import { useAuth } from '../../context/AuthContext';

export default function CustomerDashboard() {
  const { user } = useAuth();
  const stats = useFetch(() => dashboardApi.customer());
  const reqs = useFetch(() => requestsApi.list());
  const s = stats.data;
  return (
    <>
      <div className="page-title">
        <div><h2>Hello, {user.name.split(' ')[0]}</h2><div className="muted">Here is what is happening with your cars.</div></div>
        <Link to="/customer/book" className="btn btn-accent"><i className="bi bi-calendar-plus me-2"></i>Book a service</Link>
      </div>
      <Async loading={stats.loading} error={stats.error} reload={stats.reload}>
        {s && (
          <div className="row g-3 mb-4">
            <div className="col-6 col-lg"><StatCard icon="bi-car-front" label="My vehicles" value={s.myVehicles} /></div>
            <div className="col-6 col-lg"><StatCard icon="bi-calendar-check" label="Upcoming appointments" value={s.upcomingAppointments} tone="info" /></div>
            <div className="col-6 col-lg"><StatCard icon="bi-wrench" label="Active services" value={s.activeServices} tone="info" /></div>
            <div className="col-6 col-lg"><StatCard icon="bi-clock-history" label="Previous services" value={s.previousServices} tone="ok" /></div>
            <div className="col-12 col-lg"><StatCard icon="bi-credit-card" label={`Pending payments (${money(s.pendingAmount)})`} value={s.pendingPayments} tone="warn" /></div>
          </div>
        )}
      </Async>
      <div className="panel">
        <div className="panel-head"><h5 className="mb-0">Recent service requests</h5><Link to="/customer/tracking">Track services</Link></div>
        <div className="panel-body">
          <Async loading={reqs.loading} error={reqs.error} reload={reqs.reload}>
            <div className="table-responsive"><table className="table mb-0">
              <thead><tr><th>Service</th><th>Vehicle</th><th>Date</th><th>Mechanic</th><th>Status</th></tr></thead>
              <tbody>
                {(reqs.data || []).slice(0, 5).map((r) => (
                  <tr key={r.id}><td>{r.serviceName}</td><td>{r.vehicleRegistration}</td><td>{fmtDate(r.appointmentDate)} {fmtTime(r.appointmentTime)}</td><td>{r.mechanicName || '—'}</td><td><StatusBadge status={r.status} /></td></tr>
                ))}
                {reqs.data?.length === 0 && <tr><td colSpan="5" className="text-center muted py-4">No service requests yet. Book your first service.</td></tr>}
              </tbody>
            </table></div>
          </Async>
        </div>
      </div>
    </>
  );
}

import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { customersApi } from '../../services/garageApi';
import { errMsg } from '../../services/api';
import Field from '../../components/Field';
import { hasErrors, isPhone, MSG } from '../../utils/validators';

export default function Profile() {
  const { user, updateUser } = useAuth();
  const toast = useToast();
  const [form, setForm] = useState({ name: user.name, phone: user.phone || '', address: user.address || '' });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const save = async (e) => {
    e.preventDefault();
    const err = { name: form.name.trim().length >= 2 ? '' : 'Name must be at least 2 characters', phone: isPhone(form.phone) ? '' : MSG.phone };
    setErrors(err);
    if (hasErrors(err)) return;
    setBusy(true);
    try {
      updateUser(await customersApi.update(user.id, form));
      toast.success('Profile updated');
    } catch (ex) { toast.error(errMsg(ex)); } finally { setBusy(false); }
  };

  return (
    <>
      <div className="page-title"><h2>My profile</h2></div>
      <form className="panel panel-body" style={{ maxWidth: 560 }} onSubmit={save} noValidate>
        <Field label="Email (cannot be changed)"><input className="form-control" value={user.email} disabled /></Field>
        <Field label="Full name" error={errors.name}><input className={`form-control ${errors.name ? 'is-invalid' : ''}`} value={form.name} onChange={set('name')} /></Field>
        <Field label="Mobile number" error={errors.phone}><input className={`form-control ${errors.phone ? 'is-invalid' : ''}`} maxLength={10} value={form.phone} onChange={set('phone')} /></Field>
        <Field label="Address"><input className="form-control" value={form.address} onChange={set('address')} /></Field>
        <button className="btn btn-accent" disabled={busy}>{busy && <span className="spinner-border spinner-border-sm me-2"></span>}Save changes</button>
      </form>
    </>
  );
}

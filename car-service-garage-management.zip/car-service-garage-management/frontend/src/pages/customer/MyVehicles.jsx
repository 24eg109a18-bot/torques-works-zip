import { useState } from 'react';
import { Link } from 'react-router-dom';
import { vehiclesApi } from '../../services/garageApi';
import { errMsg } from '../../services/api';
import useFetch from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import { Async } from '../../components/Loader';
import DataTable from '../../components/DataTable';
import ConfirmDialog from '../../components/ConfirmDialog';
import { fmtDate } from '../../utils/format';

export default function MyVehicles() {
  const { data, loading, error, reload } = useFetch(() => vehiclesApi.list());
  const toast = useToast();
  const [del, setDel] = useState(null);

  const remove = async () => {
    try { await vehiclesApi.remove(del.id); toast.success('Vehicle removed'); reload(); } catch (e) { toast.error(errMsg(e)); }
    setDel(null);
  };
  const columns = [
    { key: 'registrationNumber', label: 'Registration', render: (v) => <strong>{v.registrationNumber}</strong> },
    { key: 'name', label: 'Vehicle', text: (v) => `${v.brand} ${v.model} ${v.variant || ''}`, render: (v) => `${v.brand} ${v.model} ${v.variant || ''}` },
    { key: 'manufacturingYear', label: 'Year' },
    { key: 'fuelType', label: 'Fuel' },
    { key: 'currentKm', label: 'Odometer', render: (v) => `${v.currentKm?.toLocaleString('en-IN')} km` },
    { key: 'insuranceExpiry', label: 'Insurance until', render: (v) => fmtDate(v.insuranceExpiry) },
    { key: 'actions', label: '', render: (v) => (
      <div className="d-flex gap-1">
        <Link to={`/customer/vehicles/${v.id}/edit`} className="btn btn-ghost btn-sm" aria-label="Edit"><i className="bi bi-pencil"></i></Link>
        <button className="btn btn-ghost btn-sm" aria-label="Delete" onClick={() => setDel(v)}><i className="bi bi-trash"></i></button>
      </div>) },
  ];
  return (
    <>
      <div className="page-title"><h2>My vehicles</h2><Link to="/customer/vehicles/new" className="btn btn-accent"><i className="bi bi-plus-lg me-2"></i>Add vehicle</Link></div>
      <div className="panel panel-body">
        <Async loading={loading} error={error} reload={reload}>
          <DataTable columns={columns} rows={data || []} empty="You have not added any vehicles yet." />
        </Async>
      </div>
      <ConfirmDialog show={!!del} danger title="Delete vehicle" confirmLabel="Delete" message={`Delete ${del?.registrationNumber}? This cannot be undone.`} onCancel={() => setDel(null)} onConfirm={remove} />
    </>
  );
}

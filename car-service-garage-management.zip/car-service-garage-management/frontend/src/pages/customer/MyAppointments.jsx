import { useState } from 'react';
import { Link } from 'react-router-dom';
import { appointmentsApi } from '../../services/garageApi';
import { errMsg } from '../../services/api';
import useFetch from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import { Async } from '../../components/Loader';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import ConfirmDialog from '../../components/ConfirmDialog';
import { fmtDate, fmtTime } from '../../utils/format';

const STATUSES = ['PENDING', 'APPROVED', 'ASSIGNED', 'IN_PROGRESS', 'WAITING_FOR_PARTS', 'COMPLETED', 'CANCELLED'];

export default function MyAppointments() {
  const { data, loading, error, reload } = useFetch(() => appointmentsApi.list());
  const toast = useToast();
  const [target, setTarget] = useState(null);

  const cancel = async () => {
    try { await appointmentsApi.setStatus(target.id, 'CANCELLED'); toast.success('Appointment cancelled'); reload(); } catch (e) { toast.error(errMsg(e)); }
    setTarget(null);
  };
  const columns = [
    { key: 'id', label: '#' },
    { key: 'serviceName', label: 'Service' },
    { key: 'vehicleRegistration', label: 'Vehicle', text: (a) => `${a.vehicleRegistration} ${a.vehicleName}`, render: (a) => <>{a.vehicleRegistration}<div className="muted small">{a.vehicleName}</div></> },
    { key: 'date', label: 'Date & time', text: (a) => a.date, render: (a) => `${fmtDate(a.date)} · ${fmtTime(a.time)}` },
    { key: 'mechanicName', label: 'Mechanic', render: (a) => a.mechanicName || '—' },
    { key: 'status', label: 'Status', render: (a) => <StatusBadge status={a.status} /> },
    { key: 'actions', label: '', render: (a) => ['PENDING', 'APPROVED'].includes(a.status) && <button className="btn btn-ghost btn-sm" onClick={() => setTarget(a)}>Cancel</button> },
  ];
  return (
    <>
      <div className="page-title"><h2>My appointments</h2><Link to="/customer/book" className="btn btn-accent">New booking</Link></div>
      <div className="panel panel-body">
        <Async loading={loading} error={error} reload={reload}>
          <DataTable columns={columns} rows={data || []} filter={{ label: 'Status', options: STATUSES, get: (a) => a.status }} empty="No appointments yet." />
        </Async>
      </div>
      <ConfirmDialog show={!!target} danger title="Cancel appointment" confirmLabel="Cancel appointment" message={`Cancel your ${target?.serviceName} booking on ${target ? fmtDate(target.date) : ''}?`} onCancel={() => setTarget(null)} onConfirm={cancel} />
    </>
  );
}

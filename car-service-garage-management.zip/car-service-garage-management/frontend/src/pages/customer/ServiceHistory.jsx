import { useState } from 'react';
import { Link } from 'react-router-dom';
import { requestsApi } from '../../services/garageApi';
import useFetch from '../../hooks/useFetch';
import { Async } from '../../components/Loader';
import DataTable from '../../components/DataTable';
import AppModal from '../../components/AppModal';
import RequestSummary from '../../components/RequestSummary';
import StatusBadge from '../../components/StatusBadge';
import { fmtDate } from '../../utils/format';

export default function ServiceHistory() {
  const { data, loading, error, reload } = useFetch(() => requestsApi.list());
  const [view, setView] = useState(null);
  const rows = (data || []).filter((r) => r.status === 'COMPLETED');
  const columns = [
    { key: 'appointmentDate', label: 'Date', render: (r) => fmtDate(r.appointmentDate) },
    { key: 'serviceName', label: 'Service' },
    { key: 'vehicleRegistration', label: 'Vehicle' },
    { key: 'mechanicName', label: 'Mechanic' },
    { key: 'paymentStatus', label: 'Payment', render: (r) => <StatusBadge status={r.paymentStatus} /> },
    { key: 'actions', label: '', render: (r) => (
      <div className="d-flex gap-1">
        <button className="btn btn-ghost btn-sm" onClick={() => setView(r)}>Details</button>
        {r.invoiceId && <Link className="btn btn-ghost btn-sm" to={`/customer/invoices/${r.invoiceId}`}>Invoice</Link>}
        {!r.feedbackGiven && <Link className="btn btn-ghost btn-sm" to="/customer/feedback">Review</Link>}
      </div>) },
  ];
  return (
    <>
      <div className="page-title"><h2>Service history</h2></div>
      <div className="panel panel-body">
        <Async loading={loading} error={error} reload={reload}>
          <DataTable columns={columns} rows={rows} empty="Completed services will appear here." />
        </Async>
      </div>
      <AppModal show={!!view} title="Service details" size="modal-lg" onClose={() => setView(null)}>{view && <RequestSummary r={view} />}</AppModal>
    </>
  );
}

import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { appointmentsApi, servicesApi, vehiclesApi } from '../../services/garageApi';
import { errMsg } from '../../services/api';
import useFetch from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import { Async } from '../../components/Loader';
import Field from '../../components/Field';
import { hasErrors } from '../../utils/validators';
import { money, todayStr } from '../../utils/format';

const SLOTS = ['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00', '17:00'];

export default function BookService() {
  const vehicles = useFetch(() => vehiclesApi.list());
  const services = useFetch(() => servicesApi.publicList());
  const toast = useToast();
  const navigate = useNavigate();
  const [form, setForm] = useState({ vehicleId: '', serviceId: '', date: '', time: '', problemDescription: '' });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const cls = (k) => `form-control ${errors[k] ? 'is-invalid' : ''}`;
  const selected = (services.data || []).find((s) => String(s.id) === form.serviceId);

  const submit = async (e) => {
    e.preventDefault();
    const err = {
      vehicleId: form.vehicleId ? '' : 'Select a vehicle',
      serviceId: form.serviceId ? '' : 'Select a service',
      date: !form.date ? 'Select a date' : form.date < todayStr() ? 'Date cannot be in the past' : new Date(form.date + 'T00:00').getDay() === 0 ? 'The garage is closed on Sundays' : '',
      time: form.time ? '' : 'Select a time slot',
      problemDescription: form.problemDescription.trim().length >= 5 ? '' : 'Please describe the problem (at least 5 characters)',
    };
    setErrors(err);
    if (hasErrors(err)) return;
    setBusy(true);
    try {
      await appointmentsApi.book({ ...form, vehicleId: Number(form.vehicleId), serviceId: Number(form.serviceId) });
      toast.success('Appointment booked. The garage will review it shortly.');
      navigate('/customer/appointments');
    } catch (ex) { toast.error(errMsg(ex)); } finally { setBusy(false); }
  };

  return (
    <>
      <div className="page-title"><h2>Book a service</h2></div>
      <Async loading={vehicles.loading || services.loading} error={vehicles.error || services.error} reload={() => { vehicles.reload(); services.reload(); }}>
        {vehicles.data?.length === 0 ? (
          <div className="panel panel-body">You need to add a vehicle before booking. <Link to="/customer/vehicles/new">Add your first vehicle</Link></div>
        ) : (
          <form className="panel panel-body" onSubmit={submit} noValidate>
            <div className="row">
              <Field className="col-md-6 mb-3" label="Vehicle" error={errors.vehicleId}>
                <select className={`form-select ${errors.vehicleId ? 'is-invalid' : ''}`} value={form.vehicleId} onChange={set('vehicleId')}>
                  <option value="">Select vehicle</option>
                  {(vehicles.data || []).map((v) => <option key={v.id} value={v.id}>{v.registrationNumber} - {v.brand} {v.model}</option>)}
                </select>
              </Field>
              <Field className="col-md-6 mb-3" label="Service" error={errors.serviceId} hint={selected ? `${selected.description} Estimated ${money(selected.estimatedCost)}, about ${selected.estimatedDurationHours} hr.` : ''}>
                <select className={`form-select ${errors.serviceId ? 'is-invalid' : ''}`} value={form.serviceId} onChange={set('serviceId')}>
                  <option value="">Select service</option>
                  {(services.data || []).map((s) => <option key={s.id} value={s.id}>{s.name} ({money(s.estimatedCost)})</option>)}
                </select>
              </Field>
              <Field className="col-md-6 mb-3" label="Preferred date" error={errors.date}><input type="date" min={todayStr()} className={cls('date')} value={form.date} onChange={set('date')} /></Field>
              <Field className="col-md-6 mb-3" label="Preferred time" error={errors.time}>
                <select className={`form-select ${errors.time ? 'is-invalid' : ''}`} value={form.time} onChange={set('time')}>
                  <option value="">Select time slot</option>
                  {SLOTS.map((t) => <option key={t}>{t}</option>)}
                </select>
              </Field>
            </div>
            <Field label="Describe the problem" error={errors.problemDescription}><textarea rows="4" maxLength={1000} className={cls('problemDescription')} placeholder="For example: brakes squeak at low speed and the pedal feels soft" value={form.problemDescription} onChange={set('problemDescription')} /></Field>
            <button className="btn btn-accent" disabled={busy}>{busy && <span className="spinner-border spinner-border-sm me-2"></span>}Book appointment</button>
          </form>
        )}
      </Async>
    </>
  );
}

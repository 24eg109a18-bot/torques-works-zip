import { Link } from 'react-router-dom';
import { requestsApi } from '../../services/garageApi';
import useFetch from '../../hooks/useFetch';
import { Async } from '../../components/Loader';
import StatusBadge from '../../components/StatusBadge';
import { fmtDate, fmtTime, money } from '../../utils/format';

const STEPS = [['PENDING', 'Requested'], ['APPROVED', 'Approved'], ['ASSIGNED', 'Mechanic assigned'], ['IN_PROGRESS', 'In progress'], ['COMPLETED', 'Completed']];

export default function ServiceTracking() {
  const { data, loading, error, reload } = useFetch(() => requestsApi.list());
  const active = (data || []).filter((r) => !['COMPLETED', 'CANCELLED'].includes(r.status));
  return (
    <>
      <div className="page-title"><h2>Service tracking</h2><button className="btn btn-ghost btn-sm" onClick={reload}><i className="bi bi-arrow-clockwise me-1"></i>Refresh</button></div>
      <Async loading={loading} error={error} reload={reload}>
        {active.length === 0 && <div className="panel panel-body muted">Nothing is in progress right now. Completed jobs are under <Link to="/customer/history">Service history</Link>.</div>}
        {active.map((r) => {
          const stage = r.status === 'WAITING_FOR_PARTS' ? 'IN_PROGRESS' : r.status;
          const idx = STEPS.findIndex(([k]) => k === stage);
          return (
            <div className="panel mb-3" key={r.id}>
              <div className="panel-head">
                <div><h5 className="mb-0">{r.serviceName}</h5><span className="muted">{r.vehicleName} · {r.vehicleRegistration} · {fmtDate(r.appointmentDate)} {fmtTime(r.appointmentTime)}</span></div>
                <StatusBadge status={r.status} />
              </div>
              <div className="panel-body">
                <div className="stepper">
                  {STEPS.map(([k, text], i) => <div key={k} className={`step ${i <= idx ? 'done' : ''} ${i === idx ? 'now' : ''}`}><div className="dot">{i < idx ? <i className="bi bi-check"></i> : i + 1}</div>{text}</div>)}
                </div>
                {r.status === 'WAITING_FOR_PARTS' && <div className="alert alert-warning py-2 mt-3 mb-0">Your mechanic is waiting for spare parts to arrive.</div>}
                <div className="row g-3 mt-1">
                  <div className="col-md-4"><div className="muted small">Assigned mechanic</div><div>{r.mechanicName || 'Waiting for assignment'}</div></div>
                  <div className="col-md-4"><div className="muted small">Estimated completion</div><div>{r.estimatedCompletionDate ? fmtDate(r.estimatedCompletionDate) : 'To be confirmed'}</div></div>
                  <div className="col-md-4"><div className="muted small">Bill so far</div><div>{money(Number(r.serviceCost) + Number(r.labourCharge) + Number(r.partsTotal))} <span className="muted small">(before GST)</span></div></div>
                  {r.inspectionNotes && <div className="col-12"><div className="muted small">Mechanic's inspection notes</div><div style={{ whiteSpace: 'pre-wrap' }}>{r.inspectionNotes}</div></div>}
                  {r.parts.length > 0 && <div className="col-12"><div className="muted small">Spare parts used</div>{r.parts.map((p) => <span key={p.id} className="badge text-bg-secondary me-1">{p.partName} × {p.quantity}</span>)}</div>}
                </div>
              </div>
            </div>
          );
        })}
      </Async>
    </>
  );
}

import { Link } from 'react-router-dom';
import { invoicesApi } from '../../services/garageApi';
import useFetch from '../../hooks/useFetch';
import { Async } from '../../components/Loader';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import { fmtDate, money } from '../../utils/format';

export default function MyInvoices() {
  const { data, loading, error, reload } = useFetch(() => invoicesApi.list());
  const columns = [
    { key: 'invoiceNumber', label: 'Invoice', render: (i) => <strong>{i.invoiceNumber}</strong> },
    { key: 'invoiceDate', label: 'Date', render: (i) => fmtDate(i.invoiceDate) },
    { key: 'serviceName', label: 'Service' },
    { key: 'vehicleRegistration', label: 'Vehicle' },
    { key: 'total', label: 'Total', render: (i) => money(i.total) },
    { key: 'paymentStatus', label: 'Payment', render: (i) => <StatusBadge status={i.paymentStatus} /> },
    { key: 'actions', label: '', render: (i) => (
      <div className="d-flex gap-1">
        <Link className="btn btn-ghost btn-sm" to={`/customer/invoices/${i.id}`}>View</Link>
        {i.paymentStatus === 'PENDING' && <Link className="btn btn-accent btn-sm" to="/customer/payment">Pay</Link>}
      </div>) },
  ];
  return (
    <>
      <div className="page-title"><h2>Invoices</h2></div>
      <div className="panel panel-body">
        <Async loading={loading} error={error} reload={reload}>
          <DataTable columns={columns} rows={data || []} empty="Invoices are created automatically when a service is completed." />
        </Async>
      </div>
    </>
  );
}

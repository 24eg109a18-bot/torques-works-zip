import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { partsApi, requestsApi } from '../../services/garageApi';
import { errMsg } from '../../services/api';
import useFetch from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import { Async } from '../../components/Loader';
import Field from '../../components/Field';
import StatusBadge from '../../components/StatusBadge';
import ConfirmDialog from '../../components/ConfirmDialog';
import RequestSummary from '../../components/RequestSummary';
import { fmtDate, label, money } from '../../utils/format';

const MECH_STATUSES = ['IN_PROGRESS', 'WAITING_FOR_PARTS', 'COMPLETED'];
const BTN = { IN_PROGRESS: ['Start / resume work', 'btn-accent'], WAITING_FOR_PARTS: ['Waiting for parts', 'btn-ghost'], COMPLETED: ['Mark as completed', 'btn-accent'] };

/** One job card with three tabs: Details, Update Service and Spare Parts Used. */
export default function ServiceDetails() {
  const { id } = useParams();
  const toast = useToast();
  const { data: r, loading, error, reload, setData } = useFetch(() => requestsApi.get(id), [id]);
  const parts = useFetch(() => partsApi.list());
  const [history, setHistory] = useState([]);
  const [tab, setTab] = useState('details');
  const [work, setWork] = useState({ inspectionNotes: '', labourCharge: '', estimatedCompletionDate: '' });
  const [errors, setErrors] = useState({});
  const [part, setPart] = useState({ partId: '', quantity: 1 });
  const [confirm, setConfirm] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!r) return;
    setWork({ inspectionNotes: r.inspectionNotes || '', labourCharge: r.labourCharge ?? '', estimatedCompletionDate: r.estimatedCompletionDate || '' });
    requestsApi.history(r.vehicleId).then(setHistory).catch(() => {});
  }, [r?.id, r?.inspectionNotes, r?.labourCharge]); // eslint-disable-line

  if (loading || error || !r) return <Async loading={loading} error={error} reload={reload} />;
  const editable = ['ASSIGNED', 'IN_PROGRESS', 'WAITING_FOR_PARTS'].includes(r.status);
  const nextOptions = r.allowedNext.filter((s) => MECH_STATUSES.includes(s));

  const run = async (fn, okMsg) => {
    setBusy(true);
    try { setData(await fn()); toast.success(okMsg); return true; } catch (e) { toast.error(errMsg(e)); return false; } finally { setBusy(false); }
  };
  const saveWork = async (e) => {
    e.preventDefault();
    const err = {
      labourCharge: work.labourCharge !== '' && Number(work.labourCharge) < 0 ? 'Labour charge cannot be negative' : '',
      estimatedCompletionDate: work.estimatedCompletionDate && work.estimatedCompletionDate < r.appointmentDate ? 'Cannot be before the appointment date' : '',
    };
    setErrors(err);
    if (err.labourCharge || err.estimatedCompletionDate) return;
    run(() => requestsApi.updateWork(r.id, { inspectionNotes: work.inspectionNotes, labourCharge: work.labourCharge === '' ? null : Number(work.labourCharge), estimatedCompletionDate: work.estimatedCompletionDate || null }), 'Job updated');
  };
  const addPart = async (e) => {
    e.preventDefault();
    if (!part.partId) return toast.error('Select a spare part');
    if (!(Number(part.quantity) >= 1)) return toast.error('Quantity must be at least 1');
    if (await run(() => requestsApi.addPart(r.id, { partId: Number(part.partId), quantity: Number(part.quantity) }), 'Part added and stock updated')) { setPart({ partId: '', quantity: 1 }); parts.reload(); }
  };
  const removePart = async (line) => { if (await run(() => requestsApi.removePart(r.id, line.id), 'Part removed and stock restored')) parts.reload(); };
  const changeStatus = async () => { await run(() => requestsApi.setStatus(r.id, confirm), `Status changed to ${label(confirm)}`); setConfirm(null); };
  const selectedPart = (parts.data || []).find((p) => String(p.id) === part.partId);

  return (
    <>
      <div className="page-title">
        <div><Link to="/mechanic/services" className="muted small"><i className="bi bi-arrow-left me-1"></i>Assigned services</Link><h2 className="mt-1">Job #{r.id}: {r.serviceName}</h2></div>
        <StatusBadge status={r.status} />
      </div>

      {nextOptions.length > 0 && (
        <div className="panel panel-body mb-3 d-flex flex-wrap gap-2 align-items-center">
          <span className="muted me-2">Update status:</span>
          {nextOptions.map((s) => <button key={s} className={`btn btn-sm ${BTN[s][1]}`} disabled={busy} onClick={() => setConfirm(s)}>{BTN[s][0]}</button>)}
        </div>
      )}

      <ul className="nav nav-tabs mb-3">
        {[['details', 'Details'], ['update', 'Update Service'], ['parts', `Spare Parts Used (${r.parts.length})`]].map(([k, t]) => (
          <li className="nav-item" key={k}><button className={`nav-link ${tab === k ? 'active' : ''}`} onClick={() => setTab(k)}>{t}</button></li>
        ))}
      </ul>

      {tab === 'details' && (
        <div className="row g-3">
          <div className="col-lg-7"><div className="panel panel-body"><RequestSummary r={r} /></div></div>
          <div className="col-lg-5"><div className="panel panel-body">
            <h5>Previous service history of this vehicle</h5>
            {history.length === 0 ? <div className="muted">No earlier completed services.</div> : history.map((h) => (
              <div key={h.id} className="py-2 border-bottom border-secondary-subtle"><strong>{h.serviceName}</strong> <span className="muted">· {fmtDate(h.appointmentDate)}</span>
                {h.inspectionNotes && <div className="small muted">{h.inspectionNotes}</div>}</div>))}
          </div></div>
        </div>
      )}

      {tab === 'update' && (
        <form className="panel panel-body" style={{ maxWidth: 680 }} onSubmit={saveWork} noValidate>
          {!editable && <div className="alert alert-secondary">This job is {label(r.status).toLowerCase()} and can no longer be edited.</div>}
          <Field label="Inspection notes / required work"><textarea rows="5" className="form-control" disabled={!editable} value={work.inspectionNotes} onChange={(e) => setWork({ ...work, inspectionNotes: e.target.value })} /></Field>
          <div className="row">
            <Field className="col-md-6 mb-3" label="Labour charges (₹)" error={errors.labourCharge}><input type="number" min="0" step="0.01" className={`form-control ${errors.labourCharge ? 'is-invalid' : ''}`} disabled={!editable} value={work.labourCharge} onChange={(e) => setWork({ ...work, labourCharge: e.target.value })} /></Field>
            <Field className="col-md-6 mb-3" label="Estimated completion date" error={errors.estimatedCompletionDate}><input type="date" className={`form-control ${errors.estimatedCompletionDate ? 'is-invalid' : ''}`} disabled={!editable} min={r.appointmentDate} value={work.estimatedCompletionDate} onChange={(e) => setWork({ ...work, estimatedCompletionDate: e.target.value })} /></Field>
          </div>
          <button className="btn btn-accent" disabled={!editable || busy}>Save updates</button>
        </form>
      )}

      {tab === 'parts' && (
        <div className="panel panel-body">
          {editable && (
            <form className="row g-2 align-items-end mb-4" onSubmit={addPart}>
              <div className="col-md-6"><label className="form-label">Spare part</label>
                <select className="form-select" value={part.partId} onChange={(e) => setPart({ ...part, partId: e.target.value })}>
                  <option value="">Select part</option>
                  {(parts.data || []).map((p) => <option key={p.id} value={p.id} disabled={p.quantity === 0}>{p.name} ({p.partNumber}) · {money(p.price)} · stock {p.quantity}</option>)}
                </select></div>
              <div className="col-md-2"><label className="form-label">Quantity</label><input type="number" min="1" max={selectedPart?.quantity || undefined} className="form-control" value={part.quantity} onChange={(e) => setPart({ ...part, quantity: e.target.value })} /></div>
              <div className="col-md-4"><button className="btn btn-accent" disabled={busy}><i className="bi bi-plus-lg me-1"></i>Add part</button></div>
            </form>
          )}
          <div className="table-responsive"><table className="table mb-0">
            <thead><tr><th>Part</th><th>Part no.</th><th className="text-end">Qty</th><th className="text-end">Unit price</th><th className="text-end">Total</th><th></th></tr></thead>
            <tbody>
              {r.parts.map((p) => <tr key={p.id}><td>{p.partName}</td><td>{p.partNumber}</td><td className="text-end">{p.quantity}</td><td className="text-end">{money(p.unitPrice)}</td><td className="text-end">{money(p.lineTotal)}</td>
                <td className="text-end">{editable && <button className="btn btn-ghost btn-sm" onClick={() => removePart(p)} aria-label="Remove"><i className="bi bi-trash"></i></button>}</td></tr>)}
              {r.parts.length === 0 && <tr><td colSpan="6" className="text-center muted py-4">No spare parts used yet.</td></tr>}
            </tbody>
            {r.parts.length > 0 && <tfoot><tr><th colSpan="4" className="text-end">Parts total</th><th className="text-end">{money(r.partsTotal)}</th><th></th></tr></tfoot>}
          </table></div>
        </div>
      )}

      <ConfirmDialog show={!!confirm} title="Change job status" message={confirm === 'COMPLETED' ? 'Mark this job as completed? The invoice will be generated automatically and the job can no longer be edited.' : `Change status to ${label(confirm)}?`} confirmLabel="Yes, update" busy={busy} onCancel={() => setConfirm(null)} onConfirm={changeStatus} />
    </>
  );
}

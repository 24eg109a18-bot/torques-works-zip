import { Link } from 'react-router-dom';
import { dashboardApi, requestsApi } from '../../services/garageApi';
import useFetch from '../../hooks/useFetch';
import { Async } from '../../components/Loader';
import StatCard from '../../components/StatCard';
import StatusBadge from '../../components/StatusBadge';
import { fmtDate, fmtTime } from '../../utils/format';
import { useAuth } from '../../context/AuthContext';

export default function MechanicDashboard() {
  const { user } = useAuth();
  const stats = useFetch(() => dashboardApi.mechanic());
  const reqs = useFetch(() => requestsApi.list());
  const s = stats.data;
  const open = (reqs.data || []).filter((r) => !['COMPLETED', 'CANCELLED'].includes(r.status));
  return (
    <>
      <div className="page-title"><div><h2>Welcome, {user.name.split(' ')[0]}</h2><div className="muted">{user.specialization}</div></div></div>
      <Async loading={stats.loading} error={stats.error} reload={stats.reload}>
        {s && <div className="row g-3 mb-4">
          <div className="col-6 col-lg-3"><StatCard icon="bi-clipboard-check" label="Assigned jobs" value={s.assignedJobs} /></div>
          <div className="col-6 col-lg-3"><StatCard icon="bi-hourglass-split" label="Pending jobs" value={s.pendingJobs} tone="info" /></div>
          <div className="col-6 col-lg-3"><StatCard icon="bi-wrench-adjustable" label="In-progress jobs" value={s.inProgressJobs} tone="warn" /></div>
          <div className="col-6 col-lg-3"><StatCard icon="bi-check2-circle" label="Completed jobs" value={s.completedJobs} tone="ok" /></div>
        </div>}
      </Async>
      <div className="panel">
        <div className="panel-head"><h5 className="mb-0">My open jobs</h5><Link to="/mechanic/services">View all</Link></div>
        <div className="panel-body"><Async loading={reqs.loading} error={reqs.error} reload={reqs.reload}>
          <div className="table-responsive"><table className="table mb-0"><thead><tr><th>Service</th><th>Vehicle</th><th>Date</th><th>Status</th><th></th></tr></thead><tbody>
            {open.map((r) => <tr key={r.id}><td>{r.serviceName}</td><td>{r.vehicleName}<div className="muted small">{r.vehicleRegistration}</div></td><td>{fmtDate(r.appointmentDate)} {fmtTime(r.appointmentTime)}</td><td><StatusBadge status={r.status} /></td><td><Link className="btn btn-ghost btn-sm" to={`/mechanic/services/${r.id}`}>Open</Link></td></tr>)}
            {open.length === 0 && <tr><td colSpan="5" className="text-center muted py-4">No open jobs right now.</td></tr>}
          </tbody></table></div>
        </Async></div>
      </div>
    </>
  );
}

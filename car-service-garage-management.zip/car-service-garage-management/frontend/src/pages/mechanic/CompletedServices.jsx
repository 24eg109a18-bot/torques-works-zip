import { useState } from 'react';
import { requestsApi } from '../../services/garageApi';
import useFetch from '../../hooks/useFetch';
import { Async } from '../../components/Loader';
import DataTable from '../../components/DataTable';
import AppModal from '../../components/AppModal';
import RequestSummary from '../../components/RequestSummary';
import { fmtDate, fmtDateTime } from '../../utils/format';

export default function CompletedServices() {
  const { data, loading, error, reload } = useFetch(() => requestsApi.list());
  const [view, setView] = useState(null);
  const rows = (data || []).filter((r) => r.status === 'COMPLETED');
  const columns = [
    { key: 'id', label: 'Job #' },
    { key: 'serviceName', label: 'Service' },
    { key: 'vehicleRegistration', label: 'Vehicle' },
    { key: 'customerName', label: 'Customer' },
    { key: 'appointmentDate', label: 'Date', render: (r) => fmtDate(r.appointmentDate) },
    { key: 'completedAt', label: 'Completed', render: (r) => fmtDateTime(r.completedAt) },
    { key: 'actions', label: '', render: (r) => <button className="btn btn-ghost btn-sm" onClick={() => setView(r)}>Details</button> },
  ];
  return (
    <>
      <div className="page-title"><h2>Completed services</h2></div>
      <div className="panel panel-body"><Async loading={loading} error={error} reload={reload}><DataTable columns={columns} rows={rows} empty="You have not completed any jobs yet." /></Async></div>
      <AppModal show={!!view} title="Job details" size="modal-lg" onClose={() => setView(null)}>{view && <RequestSummary r={view} />}</AppModal>
    </>
  );
}

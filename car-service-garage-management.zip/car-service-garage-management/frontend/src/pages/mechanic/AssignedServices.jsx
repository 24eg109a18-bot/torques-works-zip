import { Link } from 'react-router-dom';
import { requestsApi } from '../../services/garageApi';
import useFetch from '../../hooks/useFetch';
import { Async } from '../../components/Loader';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import { fmtDate, fmtTime } from '../../utils/format';

export default function AssignedServices() {
  const { data, loading, error, reload } = useFetch(() => requestsApi.list());
  const rows = (data || []).filter((r) => !['COMPLETED', 'CANCELLED'].includes(r.status));
  const columns = [
    { key: 'id', label: 'Job #' },
    { key: 'serviceName', label: 'Service' },
    { key: 'vehicleName', label: 'Vehicle', text: (r) => `${r.vehicleName} ${r.vehicleRegistration}`, render: (r) => <>{r.vehicleName}<div className="muted small">{r.vehicleRegistration}</div></> },
    { key: 'customerName', label: 'Customer' },
    { key: 'appointmentDate', label: 'Date & time', render: (r) => `${fmtDate(r.appointmentDate)} · ${fmtTime(r.appointmentTime)}` },
    { key: 'status', label: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    { key: 'actions', label: '', render: (r) => <Link className="btn btn-accent btn-sm" to={`/mechanic/services/${r.id}`}>Open job</Link> },
  ];
  return (
    <>
      <div className="page-title"><h2>Assigned services</h2></div>
      <div className="panel panel-body"><Async loading={loading} error={error} reload={reload}>
        <DataTable columns={columns} rows={rows} filter={{ label: 'Status', options: ['ASSIGNED', 'IN_PROGRESS', 'WAITING_FOR_PARTS'], get: (r) => r.status }} empty="No jobs are assigned to you." />
      </Async></div>
    </>
  );
}

import { useState } from 'react';
import { servicesApi } from '../../services/garageApi';
import { errMsg } from '../../services/api';
import useFetch from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import { Async } from '../../components/Loader';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import ConfirmDialog from '../../components/ConfirmDialog';
import AppModal from '../../components/AppModal';
import Field from '../../components/Field';
import { hasErrors } from '../../utils/validators';
import { money } from '../../utils/format';

const EMPTY = { name: '', description: '', estimatedCost: '', estimatedDurationHours: '', active: true };

export default function AdminServices() {
  const { data, loading, error, reload } = useFetch(() => servicesApi.list());
  const toast = useToast();
  const [form, setForm] = useState(null);
  const [errors, setErrors] = useState({});
  const [del, setDel] = useState(null);
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const cls = (k) => `form-control ${errors[k] ? 'is-invalid' : ''}`;

  const save = async () => {
    const err = {
      name: form.name.trim() ? '' : 'Service name is required',
      estimatedCost: Number(form.estimatedCost) > 0 ? '' : 'Estimated cost must be greater than 0',
      estimatedDurationHours: Number(form.estimatedDurationHours) >= 1 ? '' : 'Duration must be at least 1 hour',
    };
    setErrors(err);
    if (hasErrors(err)) return;
    setBusy(true);
    const body = { name: form.name, description: form.description, estimatedCost: Number(form.estimatedCost), estimatedDurationHours: Number(form.estimatedDurationHours), active: form.active };
    try {
      if (form.id) await servicesApi.update(form.id, body); else await servicesApi.create(body);
      toast.success('Service saved'); setForm(null); reload();
    } catch (e) { toast.error(errMsg(e)); } finally { setBusy(false); }
  };
  const remove = async () => {
    try { await servicesApi.remove(del.id); toast.success('Service deleted'); reload(); } catch (e) { toast.error(errMsg(e)); }
    setDel(null);
  };
  const columns = [
    { key: 'name', label: 'Service', render: (s) => <strong>{s.name}</strong> },
    { key: 'description', label: 'Description' },
    { key: 'estimatedCost', label: 'Est. cost', render: (s) => money(s.estimatedCost) },
    { key: 'estimatedDurationHours', label: 'Duration', render: (s) => `${s.estimatedDurationHours} hr` },
    { key: 'active', label: 'Status', text: (s) => (s.active ? 'active' : 'inactive'), render: (s) => <StatusBadge status={s.active ? 'ACTIVE' : 'INACTIVE'} /> },
    { key: 'actions', label: '', render: (s) => (
      <div className="d-flex gap-1">
        <button className="btn btn-ghost btn-sm" aria-label="Edit" onClick={() => { setErrors({}); setForm({ ...s }); }}><i className="bi bi-pencil"></i></button>
        <button className="btn btn-ghost btn-sm" aria-label="Delete" onClick={() => setDel(s)}><i className="bi bi-trash"></i></button>
      </div>) },
  ];
  return (
    <>
      <div className="page-title"><h2>Services</h2><button className="btn btn-accent" onClick={() => { setErrors({}); setForm(EMPTY); }}><i className="bi bi-plus-lg me-2"></i>Add service</button></div>
      <div className="panel panel-body"><Async loading={loading} error={error} reload={reload}><DataTable columns={columns} rows={data || []} filter={{ label: 'Status', options: ['active', 'inactive'], get: (s) => (s.active ? 'active' : 'inactive') }} /></Async></div>
      <AppModal show={!!form} title={form?.id ? 'Edit service' : 'Add service'} onClose={() => setForm(null)}
        footer={<><button className="btn btn-ghost" onClick={() => setForm(null)}>Cancel</button><button className="btn btn-accent" onClick={save} disabled={busy}>{busy && <span className="spinner-border spinner-border-sm me-2"></span>}Save</button></>}>
        {form && <>
          <Field label="Service name" error={errors.name}><input className={cls('name')} value={form.name} onChange={set('name')} /></Field>
          <Field label="Description"><textarea rows="3" maxLength={500} className="form-control" value={form.description || ''} onChange={set('description')} /></Field>
          <div className="row">
            <Field className="col-6 mb-3" label="Estimated cost (₹)" error={errors.estimatedCost}><input type="number" min="1" className={cls('estimatedCost')} value={form.estimatedCost} onChange={set('estimatedCost')} /></Field>
            <Field className="col-6 mb-3" label="Duration (hours)" error={errors.estimatedDurationHours}><input type="number" min="1" className={cls('estimatedDurationHours')} value={form.estimatedDurationHours} onChange={set('estimatedDurationHours')} /></Field>
          </div>
          <div className="form-check form-switch"><input className="form-check-input" type="checkbox" id="act" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} /><label className="form-check-label" htmlFor="act">Available for booking</label></div>
        </>}
      </AppModal>
      <ConfirmDialog show={!!del} danger title="Delete service" confirmLabel="Delete" message={`Delete ${del?.name}? If it is used in bookings, mark it inactive instead.`} onCancel={() => setDel(null)} onConfirm={remove} />
    </>
  );
}

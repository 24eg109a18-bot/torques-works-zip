import { useState } from 'react';
import { invoicesApi, requestsApi } from '../../services/garageApi';
import { errMsg } from '../../services/api';
import useFetch from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import { Async } from '../../components/Loader';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import AppModal from '../../components/AppModal';
import AssignModal from '../../components/AssignModal';
import RequestSummary from '../../components/RequestSummary';
import Field from '../../components/Field';
import { fmtDate, fmtTime, label } from '../../utils/format';

const STATUSES = ['PENDING', 'APPROVED', 'ASSIGNED', 'IN_PROGRESS', 'WAITING_FOR_PARTS', 'COMPLETED', 'CANCELLED'];

export default function AdminServiceRequests() {
  const { data, loading, error, reload } = useFetch(() => requestsApi.list());
  const toast = useToast();
  const [view, setView] = useState(null);
  const [assign, setAssign] = useState(null);
  const [statusFor, setStatusFor] = useState(null);
  const [next, setNext] = useState('');
  const [busy, setBusy] = useState(false);

  const changeStatus = async () => {
    if (!next) return toast.error('Select the new status');
    setBusy(true);
    try { await requestsApi.setStatus(statusFor.id, next); toast.success(`Status changed to ${label(next)}`); setStatusFor(null); reload(); }
    catch (e) { toast.error(errMsg(e)); } finally { setBusy(false); }
  };
  const makeInvoice = async (r) => { try { await invoicesApi.create(r.id); toast.success('Invoice generated'); reload(); } catch (e) { toast.error(errMsg(e)); } };
  const options = statusFor ? statusFor.allowedNext.filter((s) => s !== 'ASSIGNED') : [];

  const columns = [
    { key: 'id', label: 'Job #' },
    { key: 'serviceName', label: 'Service' },
    { key: 'vehicleRegistration', label: 'Vehicle', text: (r) => `${r.vehicleRegistration} ${r.customerName}`, render: (r) => <>{r.vehicleRegistration}<div className="muted small">{r.customerName}</div></> },
    { key: 'appointmentDate', label: 'Date & time', render: (r) => `${fmtDate(r.appointmentDate)} · ${fmtTime(r.appointmentTime)}` },
    { key: 'mechanicName', label: 'Mechanic', render: (r) => r.mechanicName || '—' },
    { key: 'status', label: 'Status', render: (r) => <StatusBadge status={r.status} /> },
    { key: 'actions', label: '', render: (r) => (
      <div className="d-flex gap-1 flex-wrap">
        <button className="btn btn-ghost btn-sm" onClick={() => setView(r)}>View</button>
        {['PENDING', 'APPROVED', 'ASSIGNED'].includes(r.status) && <button className="btn btn-ghost btn-sm" onClick={() => setAssign(r)}>Assign</button>}
        {r.allowedNext.filter((s) => s !== 'ASSIGNED').length > 0 && <button className="btn btn-ghost btn-sm" onClick={() => { setStatusFor(r); setNext(''); }}>Status</button>}
        {r.status === 'COMPLETED' && !r.invoiceId && <button className="btn btn-accent btn-sm" onClick={() => makeInvoice(r)}>Generate invoice</button>}
      </div>) },
  ];
  return (
    <>
      <div className="page-title"><h2>Service requests</h2></div>
      <div className="panel panel-body"><Async loading={loading} error={error} reload={reload}>
        <DataTable columns={columns} rows={data || []} filter={{ label: 'Status', options: STATUSES, get: (r) => r.status }} />
      </Async></div>
      <AppModal show={!!view} title={`Job #${view?.id}`} size="modal-lg" onClose={() => setView(null)}>{view && <RequestSummary r={view} />}</AppModal>
      {assign && <AssignModal requestId={assign.id} date={assign.appointmentDate} time={assign.appointmentTime} current={assign.mechanicId} onClose={() => setAssign(null)} onDone={() => { setAssign(null); reload(); }} />}
      <AppModal show={!!statusFor} title={`Change status of job #${statusFor?.id}`} onClose={() => setStatusFor(null)}
        footer={<><button className="btn btn-ghost" onClick={() => setStatusFor(null)}>Cancel</button><button className="btn btn-accent" onClick={changeStatus} disabled={busy}>Update</button></>}>
        {statusFor && <>
          <p className="muted">Current status: <StatusBadge status={statusFor.status} />. Only valid next steps are listed.</p>
          <Field label="New status"><select className="form-select" value={next} onChange={(e) => setNext(e.target.value)}><option value="">Select</option>{options.map((s) => <option key={s} value={s}>{label(s)}</option>)}</select></Field>
        </>}
      </AppModal>
    </>
  );
}

import { paymentsApi } from '../../services/garageApi';
import useFetch from '../../hooks/useFetch';
import { Async } from '../../components/Loader';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import { fmtDateTime, money } from '../../utils/format';

export default function AdminPayments() {
  const { data, loading, error, reload } = useFetch(() => paymentsApi.list());
  const columns = [
    { key: 'id', label: 'Payment ID' },
    { key: 'invoiceNumber', label: 'Invoice' },
    { key: 'customerName', label: 'Customer' },
    { key: 'amount', label: 'Amount', render: (p) => money(p.amount) },
    { key: 'method', label: 'Method' },
    { key: 'transactionId', label: 'Transaction ID' },
    { key: 'paymentDate', label: 'Date', render: (p) => fmtDateTime(p.paymentDate) },
    { key: 'status', label: 'Status', render: (p) => <StatusBadge status={p.status} /> },
  ];
  return (
    <>
      <div className="page-title"><h2>Payments</h2></div>
      <div className="panel panel-body"><Async loading={loading} error={error} reload={reload}>
        <DataTable columns={columns} rows={data || []} filter={{ label: 'Method', options: ['CASH', 'CARD', 'UPI', 'ONLINE'], get: (p) => p.method }} />
      </Async></div>
    </>
  );
}

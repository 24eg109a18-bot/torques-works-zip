import { Link } from 'react-router-dom';
import { Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { dashboardApi } from '../../services/garageApi';
import useFetch from '../../hooks/useFetch';
import { Async } from '../../components/Loader';
import StatCard from '../../components/StatCard';
import { money } from '../../utils/format';

const COLORS = ['#f2a900', '#4aa3df', '#3fb67a', '#a98bf0', '#ff8a4c', '#3cc7c7', '#e5534b'];
const tip = { contentStyle: { background: '#1a1f26', border: '1px solid #2e3643', borderRadius: 8, color: '#e8ebf0' } };
const axis = { stroke: '#9aa5b4', fontSize: 12 };

const ChartBox = ({ title, children }) => (
  <div className="panel h-100"><div className="panel-head"><h5 className="mb-0">{title}</h5></div><div className="panel-body" style={{ height: 290 }}><ResponsiveContainer width="100%" height="100%">{children}</ResponsiveContainer></div></div>
);

export default function AdminDashboard() {
  const { data: d, loading, error, reload } = useFetch(() => dashboardApi.admin());
  return (
    <>
      <div className="page-title"><h2>Admin dashboard</h2><button className="btn btn-ghost btn-sm" onClick={reload}><i className="bi bi-arrow-clockwise me-1"></i>Refresh</button></div>
      <Async loading={loading} error={error} reload={reload}>
        {d && (
          <>
            {d.lowStockParts > 0 && <div className="alert alert-warning d-flex justify-content-between align-items-center"><span><i className="bi bi-exclamation-triangle me-2"></i><strong>{d.lowStockParts}</strong> spare part(s) are below the minimum stock level.</span><Link to="/admin/inventory" className="btn btn-sm btn-outline-warning">Open inventory</Link></div>}
            <div className="row g-3 mb-4">
              {[['bi-people', 'Total customers', d.totalCustomers], ['bi-person-gear', 'Total mechanics', d.totalMechanics], ['bi-car-front', 'Total vehicles', d.totalVehicles], ['bi-hourglass-split', 'Pending appointments', d.pendingAppointments, 'warn'],
                ['bi-wrench-adjustable', 'Active services', d.activeServices, 'info'], ['bi-check2-circle', 'Completed services', d.completedServices, 'ok'], ['bi-currency-rupee', 'Total revenue', money(d.totalRevenue), 'ok'], ['bi-box-seam', 'Low stock parts', d.lowStockParts, 'warn']].map(([icon, lbl, val, tone]) => (
                <div className="col-6 col-xl-3" key={lbl}><StatCard icon={icon} label={lbl} value={val} tone={tone} /></div>))}
            </div>
            <div className="row g-3">
              <div className="col-lg-6"><ChartBox title="Monthly revenue (paid invoices)"><BarChart data={d.monthly}><CartesianGrid stroke="#2e3643" strokeDasharray="3 3" /><XAxis dataKey="month" {...axis} /><YAxis {...axis} /><Tooltip {...tip} formatter={(v) => money(v)} /><Bar dataKey="revenue" name="Revenue" fill="#f2a900" radius={[4, 4, 0, 0]} /></BarChart></ChartBox></div>
              <div className="col-lg-6"><ChartBox title="Services completed per month"><LineChart data={d.monthly}><CartesianGrid stroke="#2e3643" strokeDasharray="3 3" /><XAxis dataKey="month" {...axis} /><YAxis allowDecimals={false} {...axis} /><Tooltip {...tip} /><Line type="monotone" dataKey="completed" name="Completed" stroke="#3fb67a" strokeWidth={3} dot={{ r: 4 }} /></LineChart></ChartBox></div>
              <div className="col-lg-6"><ChartBox title="Most requested services"><BarChart data={d.topServices} layout="vertical" margin={{ left: 40 }}><CartesianGrid stroke="#2e3643" strokeDasharray="3 3" /><XAxis type="number" allowDecimals={false} {...axis} /><YAxis type="category" dataKey="name" width={130} {...axis} /><Tooltip {...tip} /><Bar dataKey="count" name="Requests" fill="#4aa3df" radius={[0, 4, 4, 0]} /></BarChart></ChartBox></div>
              <div className="col-lg-3 col-md-6"><ChartBox title="Vehicles by brand"><PieChart><Pie data={d.vehicleBrands} dataKey="count" nameKey="name" outerRadius={85} label={false}>{d.vehicleBrands.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie><Tooltip {...tip} /><Legend wrapperStyle={{ fontSize: 12 }} /></PieChart></ChartBox></div>
              <div className="col-lg-3 col-md-6"><ChartBox title="Requests by status"><PieChart><Pie data={d.statusBreakdown} dataKey="count" nameKey="name" innerRadius={45} outerRadius={85}>{d.statusBreakdown.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie><Tooltip {...tip} /><Legend wrapperStyle={{ fontSize: 11 }} formatter={(v) => v.replaceAll('_', ' ')} /></PieChart></ChartBox></div>
            </div>
          </>
        )}
      </Async>
    </>
  );
}

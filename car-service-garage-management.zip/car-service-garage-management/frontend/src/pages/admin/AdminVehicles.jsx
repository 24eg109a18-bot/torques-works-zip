import { useState } from 'react';
import { vehiclesApi } from '../../services/garageApi';
import { errMsg } from '../../services/api';
import useFetch from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import { Async } from '../../components/Loader';
import DataTable from '../../components/DataTable';
import ConfirmDialog from '../../components/ConfirmDialog';
import { fmtDate } from '../../utils/format';

export default function AdminVehicles() {
  const { data, loading, error, reload } = useFetch(() => vehiclesApi.list());
  const toast = useToast();
  const [del, setDel] = useState(null);
  const remove = async () => {
    try { await vehiclesApi.remove(del.id); toast.success('Vehicle deleted'); reload(); } catch (e) { toast.error(errMsg(e)); }
    setDel(null);
  };
  const columns = [
    { key: 'registrationNumber', label: 'Registration', render: (v) => <strong>{v.registrationNumber}</strong> },
    { key: 'name', label: 'Vehicle', text: (v) => `${v.brand} ${v.model} ${v.variant || ''}`, render: (v) => `${v.brand} ${v.model} ${v.variant || ''}` },
    { key: 'ownerName', label: 'Owner' },
    { key: 'manufacturingYear', label: 'Year' }, { key: 'fuelType', label: 'Fuel' },
    { key: 'currentKm', label: 'Odometer', render: (v) => `${v.currentKm?.toLocaleString('en-IN')} km` },
    { key: 'insuranceExpiry', label: 'Insurance', render: (v) => fmtDate(v.insuranceExpiry) },
    { key: 'actions', label: '', render: (v) => <button className="btn btn-ghost btn-sm" aria-label="Delete" onClick={() => setDel(v)}><i className="bi bi-trash"></i></button> },
  ];
  return (
    <>
      <div className="page-title"><h2>Vehicles</h2></div>
      <div className="panel panel-body"><Async loading={loading} error={error} reload={reload}><DataTable columns={columns} rows={data || []} filter={{ label: 'Fuel', options: ['Petrol', 'Diesel', 'CNG', 'Electric', 'Hybrid'], get: (v) => v.fuelType }} /></Async></div>
      <ConfirmDialog show={!!del} danger title="Delete vehicle" confirmLabel="Delete" message={`Delete ${del?.registrationNumber}? Vehicles with service history cannot be deleted.`} onCancel={() => setDel(null)} onConfirm={remove} />
    </>
  );
}

import { useState } from 'react';
import { appointmentsApi } from '../../services/garageApi';
import { errMsg } from '../../services/api';
import useFetch from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import { Async } from '../../components/Loader';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import ConfirmDialog from '../../components/ConfirmDialog';
import AssignModal from '../../components/AssignModal';
import AppModal from '../../components/AppModal';
import { fmtDate, fmtTime } from '../../utils/format';

const STATUSES = ['PENDING', 'APPROVED', 'ASSIGNED', 'IN_PROGRESS', 'WAITING_FOR_PARTS', 'COMPLETED', 'CANCELLED'];

/** Admin reviews incoming requests: approve, assign a mechanic, or cancel. */
export default function AdminAppointments() {
  const { data, loading, error, reload } = useFetch(() => appointmentsApi.list());
  const toast = useToast();
  const [assign, setAssign] = useState(null);
  const [cancel, setCancel] = useState(null);
  const [detail, setDetail] = useState(null);

  const approve = async (a) => { try { await appointmentsApi.setStatus(a.id, 'APPROVED'); toast.success('Appointment approved'); reload(); } catch (e) { toast.error(errMsg(e)); } };
  const doCancel = async () => { try { await appointmentsApi.setStatus(cancel.id, 'CANCELLED'); toast.success('Appointment cancelled'); reload(); } catch (e) { toast.error(errMsg(e)); } setCancel(null); };
  const columns = [
    { key: 'id', label: '#' },
    { key: 'customerName', label: 'Customer' },
    { key: 'vehicleRegistration', label: 'Vehicle', text: (a) => `${a.vehicleRegistration} ${a.vehicleName}`, render: (a) => <>{a.vehicleRegistration}<div className="muted small">{a.vehicleName}</div></> },
    { key: 'serviceName', label: 'Service' },
    { key: 'date', label: 'Date & time', text: (a) => a.date, render: (a) => `${fmtDate(a.date)} · ${fmtTime(a.time)}` },
    { key: 'mechanicName', label: 'Mechanic', render: (a) => a.mechanicName || '—' },
    { key: 'status', label: 'Status', render: (a) => <StatusBadge status={a.status} /> },
    { key: 'actions', label: '', render: (a) => (
      <div className="d-flex gap-1 flex-wrap">
        <button className="btn btn-ghost btn-sm" onClick={() => setDetail(a)}>View</button>
        {a.status === 'PENDING' && <button className="btn btn-accent btn-sm" onClick={() => approve(a)}>Approve</button>}
        {['PENDING', 'APPROVED', 'ASSIGNED'].includes(a.status) && <button className="btn btn-ghost btn-sm" onClick={() => setAssign(a)}>{a.mechanicName ? 'Reassign' : 'Assign'}</button>}
        {['PENDING', 'APPROVED'].includes(a.status) && <button className="btn btn-ghost btn-sm" onClick={() => setCancel(a)}>Cancel</button>}
      </div>) },
  ];
  return (
    <>
      <div className="page-title"><h2>Appointments</h2></div>
      <div className="panel panel-body"><Async loading={loading} error={error} reload={reload}>
        <DataTable columns={columns} rows={data || []} filter={{ label: 'Status', options: STATUSES, get: (a) => a.status }} />
      </Async></div>
      {assign && <AssignModal requestId={assign.serviceRequestId} date={assign.date} time={assign.time} onClose={() => setAssign(null)} onDone={() => { setAssign(null); reload(); }} />}
      <ConfirmDialog show={!!cancel} danger title="Cancel appointment" confirmLabel="Cancel appointment" message={`Cancel ${cancel?.customerName}'s ${cancel?.serviceName} appointment?`} onCancel={() => setCancel(null)} onConfirm={doCancel} />
      <AppModal show={!!detail} title={`Appointment #${detail?.id}`} onClose={() => setDetail(null)}>
        {detail && <dl className="row mb-0">
          <dt className="col-4 muted">Customer</dt><dd className="col-8">{detail.customerName}</dd>
          <dt className="col-4 muted">Vehicle</dt><dd className="col-8">{detail.vehicleName} ({detail.vehicleRegistration})</dd>
          <dt className="col-4 muted">Service</dt><dd className="col-8">{detail.serviceName}</dd>
          <dt className="col-4 muted">Slot</dt><dd className="col-8">{fmtDate(detail.date)} at {fmtTime(detail.time)}</dd>
          <dt className="col-4 muted">Problem</dt><dd className="col-8">{detail.problemDescription}</dd>
          <dt className="col-4 muted">Status</dt><dd className="col-8"><StatusBadge status={detail.status} /></dd>
        </dl>}
      </AppModal>
    </>
  );
}

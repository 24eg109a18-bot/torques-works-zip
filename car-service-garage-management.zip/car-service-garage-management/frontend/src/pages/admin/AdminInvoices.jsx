import { useState } from 'react';
import { Link } from 'react-router-dom';
import { invoicesApi } from '../../services/garageApi';
import useFetch from '../../hooks/useFetch';
import { Async } from '../../components/Loader';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import PayModal from '../../components/PayModal';
import { fmtDate, money } from '../../utils/format';

export default function AdminInvoices() {
  const { data, loading, error, reload } = useFetch(() => invoicesApi.list());
  const [paying, setPaying] = useState(null);
  const columns = [
    { key: 'invoiceNumber', label: 'Invoice', render: (i) => <strong>{i.invoiceNumber}</strong> },
    { key: 'invoiceDate', label: 'Date', render: (i) => fmtDate(i.invoiceDate) },
    { key: 'customerName', label: 'Customer' },
    { key: 'vehicleRegistration', label: 'Vehicle' },
    { key: 'serviceName', label: 'Service' },
    { key: 'total', label: 'Total', render: (i) => money(i.total) },
    { key: 'paymentStatus', label: 'Payment', render: (i) => <StatusBadge status={i.paymentStatus} /> },
    { key: 'actions', label: '', render: (i) => (
      <div className="d-flex gap-1">
        <Link className="btn btn-ghost btn-sm" to={`/admin/invoices/${i.id}`}>View</Link>
        {i.paymentStatus === 'PENDING' && <button className="btn btn-accent btn-sm" onClick={() => setPaying(i)}>Record payment</button>}
      </div>) },
  ];
  return (
    <>
      <div className="page-title"><h2>Invoices</h2></div>
      <div className="panel panel-body"><Async loading={loading} error={error} reload={reload}>
        <DataTable columns={columns} rows={data || []} filter={{ label: 'Payment', options: ['PENDING', 'PAID'], get: (i) => i.paymentStatus }} />
      </Async></div>
      {paying && <PayModal invoice={paying} onClose={() => setPaying(null)} onPaid={() => { setPaying(null); reload(); }} />}
    </>
  );
}

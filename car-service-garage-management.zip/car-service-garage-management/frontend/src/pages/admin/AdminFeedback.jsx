import { feedbackApi } from '../../services/garageApi';
import useFetch from '../../hooks/useFetch';
import { Async } from '../../components/Loader';
import DataTable from '../../components/DataTable';
import StatCard from '../../components/StatCard';
import { fmtDate } from '../../utils/format';

export default function AdminFeedback() {
  const { data, loading, error, reload } = useFetch(() => feedbackApi.list());
  const avg = data?.length ? (data.reduce((s, f) => s + f.rating, 0) / data.length).toFixed(1) : '—';
  const columns = [
    { key: 'customerName', label: 'Customer' },
    { key: 'serviceName', label: 'Service' },
    { key: 'vehicleRegistration', label: 'Vehicle' },
    { key: 'rating', label: 'Rating', render: (f) => <span className="text-warning">{'★'.repeat(f.rating)}<span className="muted">{'★'.repeat(5 - f.rating)}</span></span> },
    { key: 'comment', label: 'Comment' },
    { key: 'createdAt', label: 'Date', render: (f) => fmtDate(f.createdAt) },
  ];
  return (
    <>
      <div className="page-title"><h2>Customer feedback</h2></div>
      <Async loading={loading} error={error} reload={reload}>
        <div className="row g-3 mb-3"><div className="col-6 col-md-3"><StatCard icon="bi-star" label="Average rating" value={avg} tone="ok" /></div><div className="col-6 col-md-3"><StatCard icon="bi-chat-heart" label="Total reviews" value={data?.length || 0} tone="info" /></div></div>
        <div className="panel panel-body"><DataTable columns={columns} rows={data || []} filter={{ label: 'Rating', options: [5, 4, 3, 2, 1], get: (f) => f.rating }} /></div>
      </Async>
    </>
  );
}

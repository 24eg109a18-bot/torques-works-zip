import { useState } from 'react';
import { customersApi } from '../../services/garageApi';
import { errMsg } from '../../services/api';
import useFetch from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import { Async } from '../../components/Loader';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import ConfirmDialog from '../../components/ConfirmDialog';
import { fmtDate } from '../../utils/format';

export default function AdminCustomers() {
  const { data, loading, error, reload } = useFetch(() => customersApi.list());
  const toast = useToast();
  const [confirm, setConfirm] = useState(null); // { type, user }

  const run = async () => {
    const { type, user } = confirm;
    try {
      if (type === 'delete') await customersApi.remove(user.id); else await customersApi.toggleBlock(user.id);
      toast.success(type === 'delete' ? 'Customer deleted' : user.active ? 'Customer blocked' : 'Customer unblocked');
      reload();
    } catch (e) { toast.error(errMsg(e)); }
    setConfirm(null);
  };
  const columns = [
    { key: 'name', label: 'Name', render: (u) => <strong>{u.name}</strong> },
    { key: 'email', label: 'Email' }, { key: 'phone', label: 'Phone' }, { key: 'address', label: 'Address' },
    { key: 'createdAt', label: 'Joined', render: (u) => fmtDate(u.createdAt) },
    { key: 'active', label: 'Status', text: (u) => (u.active ? 'active' : 'blocked'), render: (u) => <StatusBadge status={u.active ? 'ACTIVE' : 'BLOCKED'} /> },
    { key: 'actions', label: '', render: (u) => (
      <div className="d-flex gap-1">
        <button className="btn btn-ghost btn-sm" onClick={() => setConfirm({ type: 'block', user: u })}>{u.active ? 'Block' : 'Unblock'}</button>
        <button className="btn btn-ghost btn-sm" aria-label="Delete" onClick={() => setConfirm({ type: 'delete', user: u })}><i className="bi bi-trash"></i></button>
      </div>) },
  ];
  return (
    <>
      <div className="page-title"><h2>Customers</h2></div>
      <div className="panel panel-body"><Async loading={loading} error={error} reload={reload}>
        <DataTable columns={columns} rows={data || []} filter={{ label: 'Status', options: ['active', 'blocked'], get: (u) => (u.active ? 'active' : 'blocked') }} />
      </Async></div>
      <ConfirmDialog show={!!confirm} danger={confirm?.type === 'delete' || confirm?.user.active} title={confirm?.type === 'delete' ? 'Delete customer' : 'Change access'}
        confirmLabel={confirm?.type === 'delete' ? 'Delete' : confirm?.user.active ? 'Block' : 'Unblock'}
        message={confirm?.type === 'delete' ? `Delete ${confirm?.user.name}? Customers with service history cannot be deleted; block them instead.` : `${confirm?.user.active ? 'Block' : 'Unblock'} ${confirm?.user.name}? ${confirm?.user.active ? 'They will no longer be able to log in.' : ''}`}
        onCancel={() => setConfirm(null)} onConfirm={run} />
    </>
  );
}

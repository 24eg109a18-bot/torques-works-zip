import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { dashboardApi } from '../../services/garageApi';
import useFetch from '../../hooks/useFetch';
import { Async } from '../../components/Loader';
import StatCard from '../../components/StatCard';
import { downloadCsv } from '../../utils/csv';
import { money } from '../../utils/format';

export default function AdminReports() {
  const { data: r, loading, error, reload } = useFetch(() => dashboardApi.report());

  const exportCsv = () => downloadCsv('garage-report.csv', [
    ['Monthly revenue'], ['Month', 'Revenue', 'Jobs completed'], ...r.monthly.map((m) => [m.month, m.revenue, m.completed]), [],
    ['Services'], ['Service', 'Completed', 'Billed amount'], ...r.servicesByType.map((s) => [s.name, s.count, s.amount]), [],
    ['Mechanics'], ['Mechanic', 'Jobs completed', 'Average rating'], ...r.mechanics.map((m) => [m.name, m.completedJobs, m.averageRating]), [],
    ['Payment methods'], ['Method', 'Payments', 'Amount'], ...r.paymentMethods.map((p) => [p.name, p.count, p.amount]),
  ]);

  return (
    <>
      <div className="page-title"><h2>Reports</h2>{r && <button className="btn btn-accent" onClick={exportCsv}><i className="bi bi-download me-2"></i>Export CSV</button>}</div>
      <Async loading={loading} error={error} reload={reload}>
        {r && <>
          <div className="row g-3 mb-4">
            <div className="col-6 col-lg-3"><StatCard icon="bi-currency-rupee" label="Revenue collected" value={money(r.totalRevenue)} tone="ok" /></div>
            <div className="col-6 col-lg-3"><StatCard icon="bi-hourglass" label="Outstanding payments" value={money(r.outstandingAmount)} tone="warn" /></div>
            <div className="col-6 col-lg-3"><StatCard icon="bi-star" label="Average customer rating" value={r.averageRating || '—'} tone="info" /></div>
          </div>
          <div className="panel mb-3"><div className="panel-head"><h5 className="mb-0">Revenue, last 12 months</h5></div>
            <div className="panel-body" style={{ height: 280 }}><ResponsiveContainer><BarChart data={r.monthly}><CartesianGrid stroke="#2e3643" strokeDasharray="3 3" /><XAxis dataKey="month" stroke="#9aa5b4" fontSize={11} /><YAxis stroke="#9aa5b4" fontSize={12} /><Tooltip contentStyle={{ background: '#1a1f26', border: '1px solid #2e3643', color: '#e8ebf0' }} formatter={(v) => money(v)} /><Bar dataKey="revenue" fill="#f2a900" radius={[4, 4, 0, 0]} /></BarChart></ResponsiveContainer></div></div>
          <div className="row g-3">
            <div className="col-lg-6"><div className="panel h-100"><div className="panel-head"><h5 className="mb-0">Completed services by type</h5></div><div className="panel-body table-responsive"><table className="table mb-0"><thead><tr><th>Service</th><th className="text-end">Jobs</th><th className="text-end">Billed</th></tr></thead><tbody>
              {r.servicesByType.map((s) => <tr key={s.name}><td>{s.name}</td><td className="text-end">{s.count}</td><td className="text-end">{money(s.amount)}</td></tr>)}
              {r.servicesByType.length === 0 && <tr><td colSpan="3" className="muted text-center py-3">No completed services yet.</td></tr>}</tbody></table></div></div></div>
            <div className="col-lg-6"><div className="panel h-100"><div className="panel-head"><h5 className="mb-0">Mechanic performance</h5></div><div className="panel-body table-responsive"><table className="table mb-0"><thead><tr><th>Mechanic</th><th className="text-end">Jobs done</th><th className="text-end">Avg rating</th></tr></thead><tbody>
              {r.mechanics.map((m) => <tr key={m.name}><td>{m.name}</td><td className="text-end">{m.completedJobs}</td><td className="text-end">{m.averageRating || '—'}</td></tr>)}</tbody></table></div></div></div>
            <div className="col-lg-6"><div className="panel"><div className="panel-head"><h5 className="mb-0">Payments by method</h5></div><div className="panel-body table-responsive"><table className="table mb-0"><thead><tr><th>Method</th><th className="text-end">Payments</th><th className="text-end">Amount</th></tr></thead><tbody>
              {r.paymentMethods.map((p) => <tr key={p.name}><td>{p.name}</td><td className="text-end">{p.count}</td><td className="text-end">{money(p.amount)}</td></tr>)}</tbody></table></div></div></div>
          </div>
        </>}
      </Async>
    </>
  );
}

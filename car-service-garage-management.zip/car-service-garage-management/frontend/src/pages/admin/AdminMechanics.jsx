import { useState } from 'react';
import { mechanicsApi } from '../../services/garageApi';
import { errMsg } from '../../services/api';
import useFetch from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import { Async } from '../../components/Loader';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import ConfirmDialog from '../../components/ConfirmDialog';
import AppModal from '../../components/AppModal';
import Field from '../../components/Field';
import { hasErrors, isEmail, isPhone, isStrongPassword, MSG } from '../../utils/validators';

const EMPTY = { name: '', email: '', phone: '', specialization: '', password: '' };

export default function AdminMechanics() {
  const { data, loading, error, reload } = useFetch(() => mechanicsApi.list());
  const toast = useToast();
  const [form, setForm] = useState(null);       // null = closed; object = open (id present when editing)
  const [errors, setErrors] = useState({});
  const [confirm, setConfirm] = useState(null);
  const [busy, setBusy] = useState(false);
  const editing = form && form.id;
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const cls = (k) => `form-control ${errors[k] ? 'is-invalid' : ''}`;

  const save = async () => {
    const err = {
      name: form.name.trim().length >= 2 ? '' : 'Name must be at least 2 characters',
      email: editing || isEmail(form.email) ? '' : MSG.email,
      phone: isPhone(form.phone) ? '' : MSG.phone,
      password: editing || isStrongPassword(form.password) ? '' : MSG.password,
    };
    setErrors(err);
    if (hasErrors(err)) return;
    setBusy(true);
    try {
      if (editing) await mechanicsApi.update(form.id, { name: form.name, phone: form.phone, address: form.address, specialization: form.specialization });
      else await mechanicsApi.create(form);
      toast.success(editing ? 'Mechanic updated' : 'Mechanic added');
      setForm(null); reload();
    } catch (e) { toast.error(errMsg(e)); } finally { setBusy(false); }
  };
  const confirmRun = async () => {
    const { type, user } = confirm;
    try {
      if (type === 'delete') await mechanicsApi.remove(user.id); else await mechanicsApi.toggleBlock(user.id);
      toast.success('Done'); reload();
    } catch (e) { toast.error(errMsg(e)); }
    setConfirm(null);
  };
  const columns = [
    { key: 'name', label: 'Name', render: (u) => <strong>{u.name}</strong> },
    { key: 'email', label: 'Email' }, { key: 'phone', label: 'Phone' }, { key: 'specialization', label: 'Specialisation' },
    { key: 'active', label: 'Status', text: (u) => (u.active ? 'active' : 'blocked'), render: (u) => <StatusBadge status={u.active ? 'ACTIVE' : 'BLOCKED'} /> },
    { key: 'actions', label: '', render: (u) => (
      <div className="d-flex gap-1">
        <button className="btn btn-ghost btn-sm" aria-label="Edit" onClick={() => { setErrors({}); setForm({ ...u }); }}><i className="bi bi-pencil"></i></button>
        <button className="btn btn-ghost btn-sm" onClick={() => setConfirm({ type: 'block', user: u })}>{u.active ? 'Block' : 'Unblock'}</button>
        <button className="btn btn-ghost btn-sm" aria-label="Delete" onClick={() => setConfirm({ type: 'delete', user: u })}><i className="bi bi-trash"></i></button>
      </div>) },
  ];
  return (
    <>
      <div className="page-title"><h2>Mechanics</h2><button className="btn btn-accent" onClick={() => { setErrors({}); setForm(EMPTY); }}><i className="bi bi-plus-lg me-2"></i>Add mechanic</button></div>
      <div className="panel panel-body"><Async loading={loading} error={error} reload={reload}><DataTable columns={columns} rows={data || []} /></Async></div>

      <AppModal show={!!form} title={editing ? 'Edit mechanic' : 'Add mechanic'} onClose={() => setForm(null)}
        footer={<><button className="btn btn-ghost" onClick={() => setForm(null)}>Cancel</button><button className="btn btn-accent" onClick={save} disabled={busy}>{busy && <span className="spinner-border spinner-border-sm me-2"></span>}Save</button></>}>
        {form && <>
          <Field label="Full name" error={errors.name}><input className={cls('name')} value={form.name} onChange={set('name')} /></Field>
          <Field label="Email" error={errors.email}><input className={cls('email')} disabled={!!editing} value={form.email} onChange={set('email')} /></Field>
          <Field label="Mobile number" error={errors.phone}><input className={cls('phone')} maxLength={10} value={form.phone || ''} onChange={set('phone')} /></Field>
          <Field label="Specialisation"><input className="form-control" placeholder="Engine, Brakes, AC..." value={form.specialization || ''} onChange={set('specialization')} /></Field>
          {!editing && <Field label="Temporary password" error={errors.password} hint={MSG.password}><input type="password" className={cls('password')} value={form.password} onChange={set('password')} /></Field>}
        </>}
      </AppModal>
      <ConfirmDialog show={!!confirm} danger title={confirm?.type === 'delete' ? 'Delete mechanic' : 'Change access'}
        message={confirm?.type === 'delete' ? `Delete ${confirm?.user.name}? Mechanics with job history cannot be deleted; block them instead.` : `${confirm?.user.active ? 'Block' : 'Unblock'} ${confirm?.user.name}?`}
        confirmLabel="Yes" onCancel={() => setConfirm(null)} onConfirm={confirmRun} />
    </>
  );
}

import { useState } from 'react';
import { partsApi } from '../../services/garageApi';
import { errMsg } from '../../services/api';
import useFetch from '../../hooks/useFetch';
import { useToast } from '../../context/ToastContext';
import { Async } from '../../components/Loader';
import DataTable from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import ConfirmDialog from '../../components/ConfirmDialog';
import AppModal from '../../components/AppModal';
import Field from '../../components/Field';
import { hasErrors } from '../../utils/validators';
import { money } from '../../utils/format';

const EMPTY = { name: '', partNumber: '', brand: '', category: '', price: '', quantity: '', minStockLevel: '' };

export default function AdminInventory() {
  const { data, loading, error, reload } = useFetch(() => partsApi.list());
  const toast = useToast();
  const [form, setForm] = useState(null);
  const [errors, setErrors] = useState({});
  const [del, setDel] = useState(null);
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const cls = (k) => `form-control ${errors[k] ? 'is-invalid' : ''}`;
  const low = (data || []).filter((p) => p.lowStock);

  const save = async () => {
    const err = {
      name: form.name.trim() ? '' : 'Part name is required',
      partNumber: form.partNumber.trim() ? '' : 'Part number is required',
      price: Number(form.price) > 0 ? '' : 'Price must be greater than 0',
      quantity: form.quantity !== '' && Number(form.quantity) >= 0 ? '' : 'Quantity cannot be negative',
      minStockLevel: form.minStockLevel !== '' && Number(form.minStockLevel) >= 0 ? '' : 'Minimum stock cannot be negative',
    };
    setErrors(err);
    if (hasErrors(err)) return;
    setBusy(true);
    const body = { name: form.name, partNumber: form.partNumber, brand: form.brand, category: form.category, price: Number(form.price), quantity: Number(form.quantity), minStockLevel: Number(form.minStockLevel) };
    try {
      if (form.id) await partsApi.update(form.id, body); else await partsApi.create(body);
      toast.success('Spare part saved'); setForm(null); reload();
    } catch (e) { toast.error(errMsg(e)); } finally { setBusy(false); }
  };
  const remove = async () => {
    try { await partsApi.remove(del.id); toast.success('Part deleted'); reload(); } catch (e) { toast.error(errMsg(e)); }
    setDel(null);
  };
  const columns = [
    { key: 'name', label: 'Part', render: (p) => <strong>{p.name}</strong> },
    { key: 'partNumber', label: 'Part no.' }, { key: 'brand', label: 'Brand' }, { key: 'category', label: 'Category' },
    { key: 'price', label: 'Price', render: (p) => money(p.price) },
    { key: 'quantity', label: 'In stock', render: (p) => <>{p.quantity} {p.lowStock && <StatusBadge status="LOW" />}</> },
    { key: 'minStockLevel', label: 'Min level' },
    { key: 'actions', label: '', render: (p) => (
      <div className="d-flex gap-1">
        <button className="btn btn-ghost btn-sm" aria-label="Edit" onClick={() => { setErrors({}); setForm({ ...p }); }}><i className="bi bi-pencil"></i></button>
        <button className="btn btn-ghost btn-sm" aria-label="Delete" onClick={() => setDel(p)}><i className="bi bi-trash"></i></button>
      </div>) },
  ];
  return (
    <>
      <div className="page-title"><h2>Inventory</h2><button className="btn btn-accent" onClick={() => { setErrors({}); setForm(EMPTY); }}><i className="bi bi-plus-lg me-2"></i>Add spare part</button></div>
      {low.length > 0 && <div className="alert alert-warning"><i className="bi bi-exclamation-triangle me-2"></i><strong>Low stock:</strong> {low.map((p) => `${p.name} (${p.quantity} left)`).join(', ')}</div>}
      <div className="panel panel-body"><Async loading={loading} error={error} reload={reload}>
        <DataTable columns={columns} rows={data || []} filter={{ label: 'Stock', options: ['low', 'ok'], get: (p) => (p.lowStock ? 'low' : 'ok') }} />
      </Async></div>
      <AppModal show={!!form} title={form?.id ? 'Edit spare part' : 'Add spare part'} onClose={() => setForm(null)}
        footer={<><button className="btn btn-ghost" onClick={() => setForm(null)}>Cancel</button><button className="btn btn-accent" onClick={save} disabled={busy}>{busy && <span className="spinner-border spinner-border-sm me-2"></span>}Save</button></>}>
        {form && <div className="row">
          <Field className="col-md-8 mb-3" label="Part name" error={errors.name}><input className={cls('name')} value={form.name} onChange={set('name')} /></Field>
          <Field className="col-md-4 mb-3" label="Part number" error={errors.partNumber}><input className={cls('partNumber')} value={form.partNumber} onChange={set('partNumber')} /></Field>
          <Field className="col-md-6 mb-3" label="Brand"><input className="form-control" value={form.brand || ''} onChange={set('brand')} /></Field>
          <Field className="col-md-6 mb-3" label="Category"><input className="form-control" value={form.category || ''} onChange={set('category')} /></Field>
          <Field className="col-md-4 mb-3" label="Price (₹)" error={errors.price}><input type="number" min="1" step="0.01" className={cls('price')} value={form.price} onChange={set('price')} /></Field>
          <Field className="col-md-4 mb-3" label="Quantity" error={errors.quantity}><input type="number" min="0" className={cls('quantity')} value={form.quantity} onChange={set('quantity')} /></Field>
          <Field className="col-md-4 mb-3" label="Min stock level" error={errors.minStockLevel}><input type="number" min="0" className={cls('minStockLevel')} value={form.minStockLevel} onChange={set('minStockLevel')} /></Field>
        </div>}
      </AppModal>
      <ConfirmDialog show={!!del} danger title="Delete spare part" confirmLabel="Delete" message={`Delete ${del?.name}? Parts that were used in jobs cannot be deleted.`} onCancel={() => setDel(null)} onConfirm={remove} />
    </>
  );
}

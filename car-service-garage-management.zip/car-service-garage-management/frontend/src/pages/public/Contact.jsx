import { useState } from 'react';
import Field from '../../components/Field';
import { isEmail } from '../../utils/validators';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [errors, setErrors] = useState({});

  // The message opens in the visitor's own mail app (no fake "sent" message).
  const submit = (e) => {
    e.preventDefault();
    const err = {
      name: form.name.trim() ? '' : 'Name is required',
      email: isEmail(form.email) ? '' : 'Enter a valid email address',
      message: form.message.trim().length >= 10 ? '' : 'Please write at least 10 characters',
    };
    setErrors(err);
    if (Object.values(err).some(Boolean)) return;
    const body = encodeURIComponent(`${form.message}\n\nFrom: ${form.name} (${form.email})`);
    window.location.href = `mailto:care@torqueworks.example?subject=${encodeURIComponent('Enquiry from ' + form.name)}&body=${body}`;
  };
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  return (
    <div className="container py-5">
      <h1>Contact us</h1>
      <div className="row g-4 mt-1">
        <div className="col-lg-5">
          <div className="panel panel-body">
            <p><i className="bi bi-geo-alt text-warning me-2"></i>Plot 21, Auto Nagar, Hyderabad 500070</p>
            <p><i className="bi bi-telephone text-warning me-2"></i>+91 98765 43210</p>
            <p><i className="bi bi-envelope text-warning me-2"></i>care@torqueworks.example</p>
            <p className="mb-0"><i className="bi bi-clock text-warning me-2"></i>Monday to Saturday, 9:00 am to 6:00 pm. Closed on Sundays.</p>
          </div>
        </div>
        <div className="col-lg-7">
          <form className="panel panel-body" onSubmit={submit} noValidate>
            <Field label="Your name" error={errors.name}><input className={`form-control ${errors.name ? 'is-invalid' : ''}`} value={form.name} onChange={set('name')} /></Field>
            <Field label="Email" error={errors.email}><input className={`form-control ${errors.email ? 'is-invalid' : ''}`} value={form.email} onChange={set('email')} /></Field>
            <Field label="Message" error={errors.message}><textarea rows="4" className={`form-control ${errors.message ? 'is-invalid' : ''}`} value={form.message} onChange={set('message')} /></Field>
            <button className="btn btn-accent">Write to us by email</button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default function About() {
  const points = [
    ['bi-people', 'Certified mechanics', 'Every job is handled by a mechanic who specialises in that system: engine, brakes or AC and electricals.'],
    ['bi-box-seam', 'Genuine spare parts', 'Parts are issued from our inventory and priced on your invoice, line by line.'],
    ['bi-eye', 'Full transparency', 'See inspection notes, parts used, labour and the final GST invoice online.'],
    ['bi-clock-history', 'Complete history', 'Every service on every vehicle is saved, so you always know what was done and when.'],
  ];
  return (
    <div className="container py-5">
      <h1>About TorqueWorks Garage</h1>
      <p className="muted fs-5" style={{ maxWidth: '44rem' }}>
        TorqueWorks is a multi-brand car service centre. This system replaces paper job cards and phone calls with one place where customers,
        mechanics and the garage owner work from the same live data.
      </p>
      <div className="row g-3 mt-2">
        {points.map(([icon, t, d]) => (
          <div className="col-md-6" key={t}><div className="service-card"><i className={`bi ${icon} fs-3 text-warning`}></i><h4 className="mt-2">{t}</h4><p className="muted mb-0">{d}</p></div></div>
        ))}
      </div>
    </div>
  );
}

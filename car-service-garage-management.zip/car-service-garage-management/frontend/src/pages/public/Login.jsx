import { useState } from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { homePath, useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { errMsg } from '../../services/api';
import Field from '../../components/Field';
import { isEmail, MSG } from '../../utils/validators';

const DEMO = [
  ['Admin', 'admin@garage.com', 'Admin@123'],
  ['Mechanic', 'ravi@garage.com', 'Mechanic@123'],
  ['Customer', 'rahul@example.com', 'Customer@123'],
];

export default function Login() {
  const { user, login } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to={homePath(user.role)} replace />;

  const submit = async (e) => {
    e.preventDefault();
    const err = { email: isEmail(form.email) ? '' : MSG.email, password: form.password ? '' : 'Password is required' };
    setErrors(err);
    if (err.email || err.password) return;
    setBusy(true);
    try {
      const u = await login(form);
      toast.success(`Welcome back, ${u.name}`);
      navigate(location.state?.from?.pathname || homePath(u.role), { replace: true });
    } catch (ex) {
      toast.error(errMsg(ex));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="container auth-wrap py-5">
      <div className="auth-card">
        <form className="panel panel-body" onSubmit={submit} noValidate>
          <h2>Log in</h2>
          <p className="muted">Customers, mechanics and admins all sign in here.</p>
          <Field label="Email" error={errors.email}>
            <input type="email" autoComplete="username" className={`form-control ${errors.email ? 'is-invalid' : ''}`} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </Field>
          <Field label="Password" error={errors.password}>
            <input type="password" autoComplete="current-password" className={`form-control ${errors.password ? 'is-invalid' : ''}`} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          </Field>
          <button className="btn btn-accent w-100" disabled={busy}>{busy && <span className="spinner-border spinner-border-sm me-2"></span>}Log in</button>
          <p className="mt-3 mb-0 text-center">New customer? <Link to="/register">Create an account</Link></p>
        </form>
        <div className="panel panel-body mt-3">
          <div className="muted small mb-2">Demo accounts (click to fill)</div>
          <div className="d-flex gap-2 flex-wrap">
            {DEMO.map(([role, email, password]) => (
              <button type="button" key={role} className="btn btn-ghost btn-sm" onClick={() => { setForm({ email, password }); setErrors({}); }}>{role}</button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

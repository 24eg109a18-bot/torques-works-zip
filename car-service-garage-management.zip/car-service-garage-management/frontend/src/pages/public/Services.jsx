import { Link } from 'react-router-dom';
import { servicesApi } from '../../services/garageApi';
import useFetch from '../../hooks/useFetch';
import { Async } from '../../components/Loader';
import { money } from '../../utils/format';

export default function Services() {
  const { data, loading, error, reload } = useFetch(() => servicesApi.publicList());
  return (
    <div className="container py-5">
      <h1>Our services</h1>
      <p className="muted">Prices are estimates. The final invoice adds labour, spare parts and 18% GST.</p>
      <Async loading={loading} error={error} reload={reload}>
        <div className="row g-3">
          {(data || []).map((s) => (
            <div className="col-md-6 col-lg-4" key={s.id}>
              <div className="service-card d-flex flex-column">
                <h4>{s.name}</h4>
                <p className="muted flex-grow-1">{s.description}</p>
                <div className="d-flex justify-content-between align-items-center mb-3">
                  <span className="price">{money(s.estimatedCost)}</span>
                  <span className="muted"><i className="bi bi-clock me-1"></i>about {s.estimatedDurationHours} hr</span>
                </div>
                <Link to="/customer/book" className="btn btn-ghost btn-sm">Book this service</Link>
              </div>
            </div>
          ))}
        </div>
      </Async>
    </div>
  );
}

import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { homePath, useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { errMsg } from '../../services/api';
import Field from '../../components/Field';
import { hasErrors, isEmail, isPhone, isStrongPassword, MSG } from '../../utils/validators';

export default function Register() {
  const { user, register } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', phone: '', address: '', password: '', confirm: '' });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to={homePath(user.role)} replace />;
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });
  const cls = (k) => `form-control ${errors[k] ? 'is-invalid' : ''}`;

  const submit = async (e) => {
    e.preventDefault();
    const err = {
      name: form.name.trim().length >= 2 ? '' : 'Name must be at least 2 characters',
      email: isEmail(form.email) ? '' : MSG.email,
      phone: isPhone(form.phone) ? '' : MSG.phone,
      password: isStrongPassword(form.password) ? '' : MSG.password,
      confirm: form.confirm === form.password ? '' : 'Passwords do not match',
    };
    setErrors(err);
    if (hasErrors(err)) return;
    setBusy(true);
    try {
      const { confirm, ...body } = form;
      await register(body);
      toast.success('Account created. Welcome to TorqueWorks!');
      navigate('/customer/vehicles/new');
    } catch (ex) {
      toast.error(errMsg(ex));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="container auth-wrap py-5">
      <form className="panel panel-body auth-card" style={{ maxWidth: 560 }} onSubmit={submit} noValidate>
        <h2>Create your account</h2>
        <div className="row">
          <Field className="col-md-6 mb-3" label="Full name" error={errors.name}><input className={cls('name')} value={form.name} onChange={set('name')} /></Field>
          <Field className="col-md-6 mb-3" label="Mobile number" error={errors.phone}><input className={cls('phone')} inputMode="numeric" maxLength={10} value={form.phone} onChange={set('phone')} /></Field>
        </div>
        <Field label="Email" error={errors.email}><input type="email" className={cls('email')} value={form.email} onChange={set('email')} /></Field>
        <Field label="Address (optional)"><input className="form-control" value={form.address} onChange={set('address')} /></Field>
        <div className="row">
          <Field className="col-md-6 mb-3" label="Password" error={errors.password} hint={MSG.password}><input type="password" autoComplete="new-password" className={cls('password')} value={form.password} onChange={set('password')} /></Field>
          <Field className="col-md-6 mb-3" label="Confirm password" error={errors.confirm}><input type="password" autoComplete="new-password" className={cls('confirm')} value={form.confirm} onChange={set('confirm')} /></Field>
        </div>
        <button className="btn btn-accent w-100" disabled={busy}>{busy && <span className="spinner-border spinner-border-sm me-2"></span>}Register</button>
        <p className="mt-3 mb-0 text-center">Already registered? <Link to="/login">Log in</Link></p>
      </form>
    </div>
  );
}

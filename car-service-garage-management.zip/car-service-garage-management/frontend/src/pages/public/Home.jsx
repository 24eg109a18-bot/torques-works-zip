import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import CarHero3D from '../../components/CarHero3D';
import useReveal from '../../hooks/useReveal';
import { servicesApi } from '../../services/garageApi';
import useFetch from '../../hooks/useFetch';
import { Async } from '../../components/Loader';
import { money } from '../../utils/format';

export default function Home() {
  useReveal();
  // parallax: hero glow layers drift as the page scrolls
  useEffect(() => {
    const hero = document.querySelector('.hero');
    let raf;
    const onScroll = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => hero && hero.style.setProperty('--py', window.scrollY)); };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => { window.removeEventListener('scroll', onScroll); cancelAnimationFrame(raf); };
  }, []);
  const { data, loading, error, reload } = useFetch(() => servicesApi.publicList());
  const steps = [
    ['bi-person-plus', 'Create an account', 'Register once and add your cars.'],
    ['bi-calendar-plus', 'Book a slot', 'Pick a service, date and time, and describe the problem.'],
    ['bi-wrench-adjustable', 'We fix it', 'An assigned mechanic inspects, repairs and updates you.'],
    ['bi-receipt', 'Pay and review', 'Get a GST invoice, pay online and rate the service.'],
  ];
  return (
    <>
      <section className="hero">
        <div className="container">
          <div className="row align-items-center g-5">
            <div className="col-lg-7">
              <h1>Book your car service.<span className="accent-line">Track it until it is back in your hands.</span></h1>
              <p className="lead mt-3">Certified mechanics, genuine spare parts and a live status for every job, from approval to invoice.</p>
              <div className="d-flex gap-2 flex-wrap mt-4">
                <Link to="/register" className="btn btn-accent btn-lg">Book a service</Link>
                <Link to="/services" className="btn btn-ghost btn-lg">See services and prices</Link>
              </div>
            </div>
            <div className="col-lg-5">
              <div className="car-stage">
                <CarHero3D />
                <div className="chip glass c1"><i className="bi bi-calendar-check"></i>Booked for 10:00</div>
                <div className="chip glass c2"><i className="bi bi-wrench-adjustable"></i>In progress</div>
                <div className="chip glass c3"><i className="bi bi-receipt"></i>Invoice ready</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="container pt-5" data-reveal>
        <h2 className="mb-4">How it works</h2>
        <div className="row g-3">
          {steps.map(([icon, title, text]) => (
            <div className="col-md-6 col-lg-3" key={title}>
              <div className="service-card"><i className={`bi ${icon} fs-2 text-warning`}></i><h5 className="mt-2">{title}</h5><p className="muted mb-0">{text}</p></div>
            </div>
          ))}
        </div>
      </section>

      <section className="container pt-5" data-reveal>
        <div className="d-flex justify-content-between align-items-end mb-3"><h2 className="mb-0">Popular services</h2><Link to="/services">All services</Link></div>
        <Async loading={loading} error={error} reload={reload}>
          <div className="row g-3">
            {(data || []).slice(0, 6).map((s) => (
              <div className="col-md-6 col-lg-4" key={s.id}>
                <div className="service-card">
                  <h5>{s.name}</h5>
                  <p className="muted">{s.description}</p>
                  <div className="d-flex justify-content-between align-items-center"><span className="price">from {money(s.estimatedCost)}</span><span className="muted small">{s.estimatedDurationHours} hr</span></div>
                </div>
              </div>
            ))}
          </div>
        </Async>
      </section>
    </>
  );
}

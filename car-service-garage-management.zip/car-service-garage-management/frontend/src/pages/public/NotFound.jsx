import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div className="container py-5 text-center">
      <h1 className="display-font" style={{ fontSize: '5rem' }}>404</h1>
      <p className="muted">This page does not exist. It may have been moved.</p>
      <Link to="/" className="btn btn-accent">Back to home</Link>
    </div>
  );
}

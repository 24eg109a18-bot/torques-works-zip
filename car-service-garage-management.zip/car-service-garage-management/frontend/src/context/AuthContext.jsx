import { createContext, useContext, useState } from 'react';
import { authApi } from '../services/garageApi';

const AuthContext = createContext(null);

export const homePath = (role) => ({ CUSTOMER: '/customer', MECHANIC: '/mechanic', ADMIN: '/admin' }[role] || '/');

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem('user') || 'null'));

  const save = (res) => {
    localStorage.setItem('token', res.token);
    localStorage.setItem('user', JSON.stringify(res.user));
    setUser(res.user);
    return res.user;
  };
  const login = async (body) => save(await authApi.login(body));
  const register = async (body) => save(await authApi.register(body));
  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
  };
  const updateUser = (u) => {
    localStorage.setItem('user', JSON.stringify(u));
    setUser(u);
  };

  return <AuthContext.Provider value={{ user, login, register, logout, updateUser }}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);

import axios from 'axios';

// All REST calls go through this single Axios instance.
const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8080/api' });

// Attach the JWT to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// If the token has expired / is invalid, send the user back to login
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401 && !window.location.pathname.startsWith('/login')) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

/** Turns any Axios error into a readable message. */
export const errMsg = (e) => {
  if (e.response?.data?.message) return e.response.data.message;
  if (e.code === 'ERR_NETWORK') return 'Cannot reach the server. Is the backend running on port 8080?';
  return e.message || 'Something went wrong';
};

export default api;

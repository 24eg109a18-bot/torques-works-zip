import api from './api';

const data = (promise) => promise.then((r) => r.data);

export const authApi = {
  login: (b) => data(api.post('/auth/login', b)),
  register: (b) => data(api.post('/auth/register', b)),
  me: () => data(api.get('/auth/me')),
};
export const customersApi = {
  list: () => data(api.get('/customers')),
  get: (id) => data(api.get(`/customers/${id}`)),
  update: (id, b) => data(api.put(`/customers/${id}`, b)),
  toggleBlock: (id) => data(api.put(`/customers/${id}/block`)),
  remove: (id) => api.delete(`/customers/${id}`),
};
export const mechanicsApi = {
  list: () => data(api.get('/mechanics')),
  create: (b) => data(api.post('/mechanics', b)),
  update: (id, b) => data(api.put(`/mechanics/${id}`, b)),
  toggleBlock: (id) => data(api.put(`/mechanics/${id}/block`)),
  remove: (id) => api.delete(`/mechanics/${id}`),
};
export const vehiclesApi = {
  list: () => data(api.get('/vehicles')),
  get: (id) => data(api.get(`/vehicles/${id}`)),
  create: (b) => data(api.post('/vehicles', b)),
  update: (id, b) => data(api.put(`/vehicles/${id}`, b)),
  remove: (id) => api.delete(`/vehicles/${id}`),
};
export const servicesApi = {
  publicList: () => data(api.get('/services/public')),
  list: () => data(api.get('/services')),
  create: (b) => data(api.post('/services', b)),
  update: (id, b) => data(api.put(`/services/${id}`, b)),
  remove: (id) => api.delete(`/services/${id}`),
};
export const appointmentsApi = {
  list: () => data(api.get('/appointments')),
  book: (b) => data(api.post('/appointments', b)),
  setStatus: (id, status) => data(api.put(`/appointments/${id}/status`, { status })),
};
export const requestsApi = {
  list: () => data(api.get('/service-requests')),
  get: (id) => data(api.get(`/service-requests/${id}`)),
  history: (vehicleId) => data(api.get(`/service-requests/vehicle/${vehicleId}/history`)),
  assign: (id, mechanicId) => data(api.put(`/service-requests/${id}/assign`, { mechanicId })),
  setStatus: (id, status) => data(api.put(`/service-requests/${id}/status`, { status })),
  updateWork: (id, b) => data(api.put(`/service-requests/${id}/work`, b)),
  addPart: (id, b) => data(api.post(`/service-requests/${id}/parts`, b)),
  removePart: (id, usedPartId) => data(api.delete(`/service-requests/${id}/parts/${usedPartId}`)),
};
export const partsApi = {
  list: () => data(api.get('/spare-parts')),
  create: (b) => data(api.post('/spare-parts', b)),
  update: (id, b) => data(api.put(`/spare-parts/${id}`, b)),
  remove: (id) => api.delete(`/spare-parts/${id}`),
};
export const invoicesApi = {
  list: () => data(api.get('/invoices')),
  get: (id) => data(api.get(`/invoices/${id}`)),
  create: (serviceRequestId) => data(api.post('/invoices', { serviceRequestId })),
};
export const paymentsApi = {
  list: () => data(api.get('/payments')),
  pay: (invoiceId, method) => data(api.post('/payments', { invoiceId, method })),
};
export const feedbackApi = {
  list: () => data(api.get('/feedback')),
  submit: (b) => data(api.post('/feedback', b)),
};
export const dashboardApi = {
  admin: () => data(api.get('/dashboard/admin')),
  customer: () => data(api.get('/dashboard/customer')),
  mechanic: () => data(api.get('/dashboard/mechanic')),
  report: () => data(api.get('/reports/summary')),
};

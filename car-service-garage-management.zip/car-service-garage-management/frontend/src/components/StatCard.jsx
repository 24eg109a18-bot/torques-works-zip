export default function StatCard({ icon, label, value, tone = '' }) {
  return (
    <div className={`stat ${tone}`}>
      <div className="d-flex justify-content-between align-items-start">
        <div>
          <div className="num">{value}</div>
          <div className="lbl">{label}</div>
        </div>
        {icon && <i className={`bi ${icon} fs-3 muted`}></i>}
      </div>
    </div>
  );
}

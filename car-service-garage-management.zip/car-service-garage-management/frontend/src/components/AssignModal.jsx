import { useState } from 'react';
import AppModal from './AppModal';
import Field from './Field';
import Loader from './Loader';
import useFetch from '../hooks/useFetch';
import { mechanicsApi, requestsApi } from '../services/garageApi';
import { errMsg } from '../services/api';
import { useToast } from '../context/ToastContext';
import { fmtDate, fmtTime } from '../utils/format';

/** Admin picks a mechanic. The backend rejects the choice if that mechanic is already booked in the same slot. */
export default function AssignModal({ requestId, date, time, current, onClose, onDone }) {
  const { data, loading } = useFetch(() => mechanicsApi.list());
  const toast = useToast();
  const [mechanicId, setMechanicId] = useState(current || '');
  const [busy, setBusy] = useState(false);
  const mechanics = (data || []).filter((m) => m.active);

  const save = async () => {
    if (!mechanicId) return toast.error('Please select a mechanic');
    setBusy(true);
    try { await requestsApi.assign(requestId, Number(mechanicId)); toast.success('Mechanic assigned'); onDone(); }
    catch (e) { toast.error(errMsg(e)); } finally { setBusy(false); }
  };
  return (
    <AppModal show title="Assign mechanic" onClose={onClose}
      footer={<><button className="btn btn-ghost" onClick={onClose}>Cancel</button><button className="btn btn-accent" onClick={save} disabled={busy}>{busy && <span className="spinner-border spinner-border-sm me-2"></span>}Assign</button></>}>
      {loading ? <Loader /> : (
        <Field label={`Mechanic for ${fmtDate(date)} at ${fmtTime(time)}`}>
          <select className="form-select" value={mechanicId} onChange={(e) => setMechanicId(e.target.value)}>
            <option value="">Select mechanic</option>
            {mechanics.map((m) => <option key={m.id} value={m.id}>{m.name} - {m.specialization || 'General'}</option>)}
          </select>
        </Field>
      )}
    </AppModal>
  );
}

import { fmtDate, fmtDateTime, fmtTime, money } from '../utils/format';
import StatusBadge from './StatusBadge';

/** Read-only details of a service request (used in modals and detail pages). */
export default function RequestSummary({ r }) {
  const labour = Number(r.labourCharge || 0);
  return (
    <div>
      <div className="row g-3 mb-3">
        <div className="col-md-6">
          <div className="muted small">Service</div>
          <div className="fw-semibold">{r.serviceName}</div>
          <div className="mt-2"><StatusBadge status={r.status} /></div>
        </div>
        <div className="col-md-6">
          <div className="muted small">Vehicle</div>
          <div className="fw-semibold">{r.vehicleName} <span className="muted">({r.vehicleRegistration})</span></div>
          <div className="muted small mt-2">Appointment</div>
          <div>{fmtDate(r.appointmentDate)} at {fmtTime(r.appointmentTime)}</div>
        </div>
        <div className="col-md-6">
          <div className="muted small">Customer</div>
          <div>{r.customerName} {r.customerPhone && <span className="muted">· {r.customerPhone}</span>}</div>
        </div>
        <div className="col-md-6">
          <div className="muted small">Mechanic</div>
          <div>{r.mechanicName || 'Not assigned yet'}</div>
        </div>
        <div className="col-12">
          <div className="muted small">Reported problem</div>
          <div>{r.problemDescription}</div>
        </div>
        {r.inspectionNotes && (
          <div className="col-12">
            <div className="muted small">Inspection notes</div>
            <div style={{ whiteSpace: 'pre-wrap' }}>{r.inspectionNotes}</div>
          </div>
        )}
        {r.estimatedCompletionDate && (
          <div className="col-md-6"><div className="muted small">Estimated completion</div><div>{fmtDate(r.estimatedCompletionDate)}</div></div>
        )}
        {r.completedAt && (
          <div className="col-md-6"><div className="muted small">Completed on</div><div>{fmtDateTime(r.completedAt)}</div></div>
        )}
      </div>

      {r.parts.length > 0 && (
        <table className="table table-sm">
          <thead><tr><th>Part</th><th className="text-end">Qty</th><th className="text-end">Unit price</th><th className="text-end">Total</th></tr></thead>
          <tbody>
            {r.parts.map((p) => (
              <tr key={p.id}><td>{p.partName}</td><td className="text-end">{p.quantity}</td><td className="text-end">{money(p.unitPrice)}</td><td className="text-end">{money(p.lineTotal)}</td></tr>
            ))}
          </tbody>
        </table>
      )}
      <div className="d-flex justify-content-between"><span className="muted">Service estimate</span><span>{money(r.serviceCost)}</span></div>
      <div className="d-flex justify-content-between"><span className="muted">Labour</span><span>{money(labour)}</span></div>
      <div className="d-flex justify-content-between"><span className="muted">Spare parts</span><span>{money(r.partsTotal)}</span></div>
    </div>
  );
}

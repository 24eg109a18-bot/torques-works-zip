export default function Loader({ text = 'Loading...' }) {
  return (
    <div className="d-flex align-items-center justify-content-center gap-2 py-5 muted" role="status">
      <div className="spinner-border spinner-border-sm text-warning"></div>
      <span>{text}</span>
    </div>
  );
}

/** Shows a spinner, an error box (with retry) or the children. */
export function Async({ loading, error, reload, children }) {
  if (loading) return <Loader />;
  if (error)
    return (
      <div className="alert alert-danger d-flex justify-content-between align-items-center">
        <span><i className="bi bi-exclamation-triangle me-2"></i>{error}</span>
        {reload && <button className="btn btn-sm btn-outline-light" onClick={reload}>Try again</button>}
      </div>
    );
  return children;
}

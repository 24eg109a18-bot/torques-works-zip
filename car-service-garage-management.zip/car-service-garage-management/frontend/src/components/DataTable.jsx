import { useEffect, useMemo, useState } from 'react';

/**
 * Reusable table with search, optional dropdown filter and pagination.
 * columns: [{ key, label, render?(row), text?(row) }]   filter: { label, options:[...], get(row) }
 */
export default function DataTable({ columns, rows, filter, pageSize = 8, empty = 'No records found', searchable = true }) {
  const [q, setQ] = useState('');
  const [f, setF] = useState('ALL');
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return (rows || []).filter((r) => {
      if (filter && f !== 'ALL' && String(filter.get(r)) !== f) return false;
      if (!needle) return true;
      return columns.some((c) => String(c.text ? c.text(r) : r[c.key] ?? '').toLowerCase().includes(needle));
    });
  }, [rows, q, f, columns, filter]);

  useEffect(() => setPage(1), [q, f]);
  const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const current = Math.min(page, pages);
  const slice = filtered.slice((current - 1) * pageSize, current * pageSize);

  return (
    <div>
      {(searchable || filter) && (
        <div className="d-flex gap-2 flex-wrap mb-3">
          {searchable && (
            <div className="input-group" style={{ maxWidth: 320 }}>
              <span className="input-group-text bg-transparent"><i className="bi bi-search"></i></span>
              <input className="form-control" placeholder="Search..." value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search" />
            </div>
          )}
          {filter && (
            <select className="form-select" style={{ maxWidth: 220 }} value={f} onChange={(e) => setF(e.target.value)} aria-label={filter.label}>
              <option value="ALL">{filter.label}: All</option>
              {filter.options.map((o) => <option key={o} value={o}>{String(o).replaceAll('_', ' ')}</option>)}
            </select>
          )}
        </div>
      )}
      <div className="table-responsive">
        <table className="table table-hover align-middle mb-0">
          <thead><tr>{columns.map((c) => <th key={c.key}>{c.label}</th>)}</tr></thead>
          <tbody>
            {slice.length === 0 && (
              <tr><td colSpan={columns.length} className="text-center muted py-4">{empty}</td></tr>
            )}
            {slice.map((r, i) => (
              <tr key={r.id ?? i}>
                {columns.map((c) => <td key={c.key}>{c.render ? c.render(r) : r[c.key] ?? '—'}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {filtered.length > pageSize && (
        <div className="d-flex justify-content-between align-items-center mt-3 flex-wrap gap-2">
          <small className="muted">Showing {(current - 1) * pageSize + 1}-{Math.min(current * pageSize, filtered.length)} of {filtered.length}</small>
          <div className="btn-group btn-group-sm">
            <button className="btn btn-ghost" disabled={current === 1} onClick={() => setPage(current - 1)}>Previous</button>
            <button className="btn btn-ghost disabled">{current} / {pages}</button>
            <button className="btn btn-ghost" disabled={current === pages} onClick={() => setPage(current + 1)}>Next</button>
          </div>
        </div>
      )}
    </div>
  );
}

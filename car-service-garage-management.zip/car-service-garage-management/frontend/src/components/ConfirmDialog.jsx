import AppModal from './AppModal';

export default function ConfirmDialog({ show, title = 'Please confirm', message, confirmLabel = 'Confirm', danger = false, busy = false, onConfirm, onCancel }) {
  return (
    <AppModal
      show={show}
      title={title}
      onClose={onCancel}
      footer={
        <>
          <button className="btn btn-ghost" onClick={onCancel}>Cancel</button>
          <button className={`btn ${danger ? 'btn-danger' : 'btn-accent'}`} onClick={onConfirm} disabled={busy}>
            {busy && <span className="spinner-border spinner-border-sm me-2"></span>}{confirmLabel}
          </button>
        </>
      }
    >
      <p className="mb-0">{message}</p>
    </AppModal>
  );
}

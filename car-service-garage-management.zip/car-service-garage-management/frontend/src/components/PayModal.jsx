import { useState } from 'react';
import AppModal from './AppModal';
import Field from './Field';
import { useToast } from '../context/ToastContext';
import { paymentsApi } from '../services/garageApi';
import { errMsg } from '../services/api';
import { money } from '../utils/format';

const METHODS = ['UPI', 'CARD', 'ONLINE', 'CASH'];

/** Simulated payment. Card/UPI details are only validated, never stored or sent. */
export default function PayModal({ invoice, onClose, onPaid }) {
  const toast = useToast();
  const [method, setMethod] = useState('UPI');
  const [extra, setExtra] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const validate = () => {
    if (method === 'UPI' && !/^[\w.-]{2,}@[a-z]{2,}$/i.test(extra)) return 'Enter a valid UPI ID, for example name@upi';
    if (method === 'CARD' && !/^\d{16}$/.test(extra.replace(/\s/g, ''))) return 'Enter a 16-digit card number';
    return '';
  };

  const pay = async () => {
    const v = validate();
    setError(v);
    if (v) return;
    setBusy(true);
    try {
      const p = await paymentsApi.pay(invoice.id, method);
      toast.success(`Payment successful. Transaction ${p.transactionId}`);
      onPaid();
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AppModal show title={`Pay invoice ${invoice.invoiceNumber}`} onClose={onClose}
      footer={<><button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        <button className="btn btn-accent" onClick={pay} disabled={busy}>{busy && <span className="spinner-border spinner-border-sm me-2"></span>}Pay {money(invoice.total)}</button></>}>
      <Field label="Payment method">
        <select className="form-select" value={method} onChange={(e) => { setMethod(e.target.value); setExtra(''); setError(''); }}>
          {METHODS.map((m) => <option key={m}>{m}</option>)}
        </select>
      </Field>
      {method === 'UPI' && <Field label="UPI ID" error={error}><input className={`form-control ${error ? 'is-invalid' : ''}`} placeholder="name@upi" value={extra} onChange={(e) => setExtra(e.target.value)} /></Field>}
      {method === 'CARD' && <Field label="Card number" error={error}><input className={`form-control ${error ? 'is-invalid' : ''}`} inputMode="numeric" placeholder="1234 5678 9012 3456" value={extra} onChange={(e) => setExtra(e.target.value)} /></Field>}
      {method === 'CASH' && <p className="muted">Cash payment is recorded as received at the garage counter.</p>}
      <div className="alert alert-secondary mb-0 small">Payments are simulated for this project. No real money moves and card or UPI details are not stored.</div>
    </AppModal>
  );
}

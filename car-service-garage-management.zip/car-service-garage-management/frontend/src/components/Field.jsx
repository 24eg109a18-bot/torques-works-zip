/** Label + control + validation message. */
export default function Field({ label, error, children, className = 'mb-3', hint }) {
  return (
    <div className={className}>
      {label && <label className="form-label">{label}</label>}
      {children}
      {hint && !error && <div className="form-text">{hint}</div>}
      {error && <div className="invalid-feedback d-block">{error}</div>}
    </div>
  );
}

import { useEffect, useRef } from 'react';
import * as THREE from 'three';

/**
 * Floating, rotating 3D car built only from Three.js primitives (no model files needed).
 * It follows the mouse slightly, spins its wheels and hovers above a glowing service-bay platform.
 */
export default function CarHero3D() {
  const mount = useRef(null);

  useEffect(() => {
    const el = mount.current;
    if (!el) return undefined;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 100);
    camera.position.set(6.2, 3, 7.2);
    camera.lookAt(0, 0.7, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    el.appendChild(renderer.domElement);

    scene.add(new THREE.AmbientLight(0xffffff, 0.7));
    const key = new THREE.DirectionalLight(0xffffff, 2.2);
    key.position.set(4, 7, 4);
    scene.add(key);
    const rim = new THREE.PointLight(0xf2a900, 60, 25);
    rim.position.set(-5, 2.5, -3);
    scene.add(rim);
    const fill = new THREE.PointLight(0x4aa3df, 35, 25);
    fill.position.set(5, 1.5, -4);
    scene.add(fill);

    const paint = new THREE.MeshStandardMaterial({ color: 0xf2a900, metalness: 0.65, roughness: 0.28 });
    const dark = new THREE.MeshStandardMaterial({ color: 0x14181e, metalness: 0.4, roughness: 0.55 });
    const glass = new THREE.MeshPhysicalMaterial({ color: 0x78b9ff, metalness: 0, roughness: 0.05, transparent: true, opacity: 0.6 });
    const chrome = new THREE.MeshStandardMaterial({ color: 0xdfe5ec, metalness: 1, roughness: 0.2 });
    const headMat = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff2c0, emissiveIntensity: 2 });
    const tailMat = new THREE.MeshStandardMaterial({ color: 0xff3b30, emissive: 0xff3b30, emissiveIntensity: 1.6 });

    const car = new THREE.Group();
    const add = (geo, mat, x, y, z) => {
      const m = new THREE.Mesh(geo, mat);
      m.position.set(x, y, z);
      car.add(m);
      return m;
    };
    add(new THREE.BoxGeometry(4.2, 0.62, 1.9), paint, 0, 0.72, 0);            // lower body
    add(new THREE.BoxGeometry(3.6, 0.28, 1.86), paint, 0, 1.12, 0);           // shoulder line
    add(new THREE.BoxGeometry(2.1, 0.66, 1.6), glass, -0.25, 1.52, 0);        // cabin glass
    add(new THREE.BoxGeometry(2.2, 0.09, 1.68), paint, -0.25, 1.88, 0);       // roof
    add(new THREE.BoxGeometry(0.12, 0.7, 1.64), paint, 0.82, 1.5, 0);         // windscreen pillar
    add(new THREE.BoxGeometry(0.12, 0.7, 1.64), paint, -1.32, 1.5, 0);        // rear pillar
    add(new THREE.BoxGeometry(0.2, 0.3, 1.7), dark, 2.12, 0.5, 0);            // front bumper
    add(new THREE.BoxGeometry(0.2, 0.3, 1.7), dark, -2.12, 0.5, 0);           // rear bumper
    add(new THREE.BoxGeometry(0.06, 0.2, 0.55), headMat, 2.12, 0.86, 0.6);    // headlights
    add(new THREE.BoxGeometry(0.06, 0.2, 0.55), headMat, 2.12, 0.86, -0.6);
    add(new THREE.BoxGeometry(0.06, 0.18, 0.5), tailMat, -2.12, 0.9, 0.62);   // tail lights
    add(new THREE.BoxGeometry(0.06, 0.18, 0.5), tailMat, -2.12, 0.9, -0.62);
    add(new THREE.BoxGeometry(0.04, 0.12, 0.7), chrome, 2.13, 0.62, 0);       // grille

    const wheels = [];
    [[1.35, 0.95], [1.35, -0.95], [-1.35, 0.95], [-1.35, -0.95]].forEach(([x, z]) => {
      const g = new THREE.Group();
      const tyre = new THREE.Mesh(new THREE.CylinderGeometry(0.46, 0.46, 0.38, 32), dark);
      tyre.rotation.x = Math.PI / 2;
      const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.4, 6), chrome);
      rim.rotation.x = Math.PI / 2;
      g.add(tyre, rim);
      g.position.set(x, 0.46, z);
      car.add(g);
      wheels.push(g);
    });
    car.position.y = 0.35;
    scene.add(car);

    // service-bay platform
    const disc = new THREE.Mesh(new THREE.CylinderGeometry(3.6, 3.6, 0.08, 64), new THREE.MeshStandardMaterial({ color: 0x151a21, metalness: 0.7, roughness: 0.4 }));
    disc.position.y = -0.04;
    scene.add(disc);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(3.45, 0.035, 16, 120), new THREE.MeshStandardMaterial({ color: 0xf2a900, emissive: 0xf2a900, emissiveIntensity: 1.5 }));
    ring.rotation.x = Math.PI / 2;
    scene.add(ring);
    const ring2 = ring.clone();
    ring2.scale.set(0.72, 0.72, 0.72);
    ring2.material = ring.material.clone();
    ring2.material.emissiveIntensity = 0.6;
    scene.add(ring2);

    const mouse = { x: 0, y: 0 };
    const onMove = (e) => {
      mouse.x = (e.clientX / window.innerWidth) * 2 - 1;
      mouse.y = (e.clientY / window.innerHeight) * 2 - 1;
    };
    window.addEventListener('pointermove', onMove);

    const resize = () => {
      const w = el.clientWidth || 400;
      const h = el.clientHeight || 400;
      renderer.setSize(w, h);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(el);

    let raf;
    const clock = new THREE.Clock();
    const tick = () => {
      const t = clock.getElapsedTime();
      if (!reduce) {
        car.rotation.y = t * 0.35 + mouse.x * 0.6;
        car.rotation.z = Math.sin(t * 0.8) * 0.02 + mouse.y * 0.03;
        car.position.y = 0.35 + Math.sin(t * 1.4) * 0.12;      // floating
        wheels.forEach((w) => { w.rotation.z -= 0.05; });
        ring.rotation.z = t * 0.2;
        ring2.rotation.z = -t * 0.35;
      }
      renderer.render(scene, camera);
      raf = requestAnimationFrame(tick);
    };
    tick();

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('pointermove', onMove);
      ro.disconnect();
      scene.traverse((o) => {
        if (o.geometry) o.geometry.dispose();
        if (o.material) (Array.isArray(o.material) ? o.material : [o.material]).forEach((m) => m.dispose());
      });
      renderer.dispose();
      if (renderer.domElement.parentNode === el) el.removeChild(renderer.domElement);
    };
  }, []);

  return <div ref={mount} className="car3d" role="img" aria-label="Animated 3D car on a service bay" />;
}

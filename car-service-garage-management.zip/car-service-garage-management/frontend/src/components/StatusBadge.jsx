import { label } from '../utils/format';

export default function StatusBadge({ status }) {
  if (!status) return null;
  return <span className={`sbadge s-${status}`}>{label(status)}</span>;
}

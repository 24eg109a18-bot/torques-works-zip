import { Navigate, useLocation } from 'react-router-dom';
import { homePath, useAuth } from '../context/AuthContext';

/** Only lets users with one of the given roles in. Everyone else is redirected. */
export default function ProtectedRoute({ roles, children }) {
  const { user } = useAuth();
  const location = useLocation();
  if (!user) return <Navigate to="/login" state={{ from: location }} replace />;
  if (!roles.includes(user.role)) return <Navigate to={homePath(user.role)} replace />;
  return children;
}
